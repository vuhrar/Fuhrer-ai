"""
Fuhrer Backend — Ollama AI Provider.
Handles communication with the local Ollama server for LLM inference.
Supports streaming and non-streaming responses with retry logic.
"""
from collections.abc import AsyncGenerator
from typing import Any

import httpx

from kernel.config import settings
from kernel.exceptions import AIProviderError, ModelNotFoundError
from kernel.logging import get_logger

logger = get_logger(__name__)

OLLAMA_GENERATE_URL = "{base}/api/generate"
OLLAMA_CHAT_URL = "{base}/api/chat"
OLLAMA_TAGS_URL = "{base}/api/tags"


class OllamaProvider:
    """
    Async HTTP client for Ollama local AI server.
    Supports chat completions with streaming.
    """

    def __init__(
        self,
        base_url: str | None = None,
        default_model: str | None = None,
        timeout: int | None = None,
        max_retries: int | None = None,
    ) -> None:
        self._base_url = (base_url or settings.ollama_url).rstrip("/")
        self._default_model = default_model or settings.ollama_default_model
        self._timeout = timeout or settings.ollama_timeout_seconds
        self._max_retries = max_retries or settings.ollama_max_retries

    def _build_client(self) -> httpx.AsyncClient:
        return httpx.AsyncClient(
            base_url=self._base_url,
            timeout=httpx.Timeout(self._timeout),
        )

    async def list_models(self) -> list[str]:
        """Return list of available model names from Ollama."""
        async with self._build_client() as client:
            try:
                response = await client.get("/api/tags")
                response.raise_for_status()
                return [m["name"] for m in response.json().get("models", [])]
            except httpx.ConnectError:
                raise AIProviderError(
                    f"Cannot connect to Ollama at {self._base_url}. "
                    "Ensure Ollama is running: `ollama serve`"
                )
            except Exception as exc:
                raise AIProviderError(f"Failed to list models: {exc}") from exc

    async def chat(
        self,
        messages: list[dict[str, str]],
        model: str | None = None,
        temperature: float = 0.7,
        max_tokens: int | None = None,
        stream: bool = False,
    ) -> dict[str, Any]:
        """
        Send a chat completion request to Ollama.
        Returns the full response as a dict.
        """
        model_name = model or self._default_model
        payload: dict[str, Any] = {
            "model": model_name,
            "messages": messages,
            "stream": False,
            "options": {"temperature": temperature},
        }
        if max_tokens:
            payload["options"]["num_predict"] = max_tokens

        last_exc: Exception | None = None
        for attempt in range(self._max_retries + 1):
            try:
                async with self._build_client() as client:
                    response = await client.post("/api/chat", json=payload)
                    if response.status_code == 404:
                        raise ModelNotFoundError(model_name)
                    response.raise_for_status()
                    data = response.json()
                    return {
                        "content": data["message"]["content"],
                        "model": data.get("model", model_name),
                        "tokens_used": data.get("eval_count"),
                        "done": data.get("done", True),
                    }
            except (ModelNotFoundError, AIProviderError):
                raise
            except Exception as exc:
                last_exc = exc
                if attempt < self._max_retries:
                    logger.warning(
                        f"Ollama request failed (attempt {attempt + 1}/{self._max_retries + 1}): {exc}"
                    )

        raise AIProviderError(
            f"Ollama request failed after {self._max_retries + 1} attempts: {last_exc}"
        )

    async def stream_chat(
        self,
        messages: list[dict[str, str]],
        model: str | None = None,
        temperature: float = 0.7,
    ) -> AsyncGenerator[str, None]:
        """
        Stream a chat completion response token by token.
        Yields content chunks as they arrive.
        """
        import json

        model_name = model or self._default_model
        payload: dict[str, Any] = {
            "model": model_name,
            "messages": messages,
            "stream": True,
            "options": {"temperature": temperature},
        }

        async with self._build_client() as client:
            try:
                async with client.stream("POST", "/api/chat", json=payload) as response:
                    if response.status_code == 404:
                        raise ModelNotFoundError(model_name)
                    response.raise_for_status()
                    async for line in response.aiter_lines():
                        if not line:
                            continue
                        try:
                            chunk = json.loads(line)
                            content = chunk.get("message", {}).get("content", "")
                            if content:
                                yield content
                            if chunk.get("done"):
                                break
                        except json.JSONDecodeError:
                            continue
            except (ModelNotFoundError, AIProviderError):
                raise
            except Exception as exc:
                raise AIProviderError(f"Streaming failed: {exc}") from exc

    async def is_available(self) -> bool:
        """Check if the Ollama server is reachable."""
        try:
            async with self._build_client() as client:
                response = await client.get("/api/tags", timeout=3.0)
                return response.status_code == 200
        except Exception:
            return False


# Default provider instance
ollama = OllamaProvider()
