"""
Fuhrer Backend — Authentication Service.
Handles user registration, login, token refresh, and logout.
"""
from sqlalchemy.ext.asyncio import AsyncSession

from backend.database.repositories.user_repo import UserRepository
from kernel.exceptions import AuthenticationError, ConflictError
from kernel.logging import get_logger
from kernel.security import (
    create_access_token,
    create_refresh_token,
    get_subject_from_token,
    hash_password,
    needs_rehash,
    verify_password,
)
from kernel.security.tokens import TOKEN_TYPE_REFRESH, decode_token

logger = get_logger(__name__)


class AuthService:
    """Handles all authentication and authorization logic."""

    def __init__(self, session: AsyncSession) -> None:
        self._repo = UserRepository(session)
        self._session = session

    async def register(
        self,
        username: str,
        email: str,
        password: str,
        full_name: str | None = None,
    ) -> dict:
        """Register a new user and return token pair."""
        hashed = hash_password(password)
        user = await self._repo.create_user(
            username=username,
            email=email,
            hashed_password=hashed,
            full_name=full_name,
        )
        logger.info(f"New user registered: {username} ({email})")
        return self._build_token_response(user.id, user.username)

    async def login(self, username_or_email: str, password: str) -> dict:
        """Authenticate user and return token pair."""
        # Try email first, then username
        user = await self._repo.get_by_email(username_or_email)
        if user is None:
            user = await self._repo.get_by_username(username_or_email)

        if user is None or not user.is_active:
            raise AuthenticationError("Invalid credentials.")

        if not verify_password(password, user.hashed_password):
            raise AuthenticationError("Invalid credentials.")

        # Rehash if parameters changed
        if needs_rehash(user.hashed_password):
            await self._repo.update(user.id, hashed_password=hash_password(password))
            logger.info(f"Password rehashed for user: {user.username}")

        logger.info(f"User logged in: {user.username}")
        return self._build_token_response(user.id, user.username)

    async def refresh(self, refresh_token: str) -> dict:
        """Issue a new access token from a valid refresh token."""
        payload = decode_token(refresh_token, expected_type=TOKEN_TYPE_REFRESH)
        user_id = payload.get("sub")
        user = await self._repo.get_by_id(str(user_id))
        if not user.is_active:
            raise AuthenticationError("Account is disabled.")
        return self._build_token_response(user.id, user.username)

    @staticmethod
    def _build_token_response(user_id: str, username: str) -> dict:
        return {
            "access_token": create_access_token(user_id, {"username": username}),
            "refresh_token": create_refresh_token(user_id),
            "token_type": "bearer",
        }
