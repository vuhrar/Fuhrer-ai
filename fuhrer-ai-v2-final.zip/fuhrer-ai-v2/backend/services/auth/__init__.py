"""Auth Service."""
from .service import AuthService

__all__ = ["AuthService"]
