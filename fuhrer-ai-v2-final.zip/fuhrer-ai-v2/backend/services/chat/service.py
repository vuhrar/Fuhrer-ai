"""
Fuhrer Backend — Chat Service.
Orchestrates conversations between users and the AI provider.
"""
from collections.abc import AsyncGenerator

from sqlalchemy.ext.asyncio import AsyncSession

from backend.database.repositories.conversation_repo import ConversationRepository
from backend.services.ai.ollama_provider import OllamaProvider, ollama
from kernel.exceptions import AuthorizationError, NotFoundError
from kernel.logging import get_logger

logger = get_logger(__name__)

SYSTEM_PROMPT = (
    "You are Fuhrer AI, a helpful, accurate, and privacy-focused local AI assistant. "
    "You run entirely on the user's device. Be concise, honest, and helpful."
)


class ChatService:
    """Manages chat sessions and message history."""

    def __init__(
        self,
        session: AsyncSession,
        provider: OllamaProvider | None = None,
    ) -> None:
        self._repo = ConversationRepository(session)
        self._provider = provider or ollama

    async def create_conversation(
        self,
        user_id: str,
        title: str = "New Conversation",
        model: str | None = None,
    ) -> dict:
        from kernel.config import settings
        conv = await self._repo.create(
            user_id=user_id,
            title=title,
            model=model or settings.ollama_default_model,
        )
        return self._serialize_conversation(conv)

    async def list_conversations(self, user_id: str) -> list[dict]:
        convs = await self._repo.get_user_conversations(user_id)
        return [self._serialize_conversation(c) for c in convs]

    async def get_conversation(self, conversation_id: str, user_id: str) -> dict:
        conv = await self._repo.get_with_messages(conversation_id)
        if conv is None:
            raise NotFoundError("Conversation", conversation_id)
        if conv.user_id != user_id:
            raise AuthorizationError("You do not have access to this conversation.")
        return self._serialize_conversation(conv, include_messages=True)

    async def send_message(
        self,
        conversation_id: str,
        user_id: str,
        content: str,
    ) -> dict:
        """Send a user message and get an AI response."""
        conv = await self._repo.get_with_messages(conversation_id)
        if conv is None:
            raise NotFoundError("Conversation", conversation_id)
        if conv.user_id != user_id:
            raise AuthorizationError("You do not have access to this conversation.")

        # Save user message
        await self._repo.add_message(conversation_id, role="user", content=content)

        # Build message history for the AI
        history = [{"role": "system", "content": SYSTEM_PROMPT}]
        for msg in conv.messages:
            history.append({"role": msg.role, "content": msg.content})
        history.append({"role": "user", "content": content})

        # Get AI response
        ai_response = await self._provider.chat(
            messages=history,
            model=conv.model,
        )

        # Save assistant message
        assistant_msg = await self._repo.add_message(
            conversation_id,
            role="assistant",
            content=ai_response["content"],
            model=ai_response.get("model"),
            tokens_used=ai_response.get("tokens_used"),
        )

        # Update conversation title if it's the first message
        if len(conv.messages) == 0:
            title = content[:60] + ("..." if len(content) > 60 else "")
            await self._repo.update(conversation_id, title=title)

        return {
            "id": assistant_msg.id,
            "role": "assistant",
            "content": ai_response["content"],
            "model": ai_response.get("model"),
            "tokens_used": ai_response.get("tokens_used"),
        }

    async def stream_message(
        self,
        conversation_id: str,
        user_id: str,
        content: str,
    ) -> AsyncGenerator[str, None]:
        """Stream an AI response token by token."""
        conv = await self._repo.get_with_messages(conversation_id)
        if conv is None:
            raise NotFoundError("Conversation", conversation_id)
        if conv.user_id != user_id:
            raise AuthorizationError("You do not have access to this conversation.")

        await self._repo.add_message(conversation_id, role="user", content=content)

        history = [{"role": "system", "content": SYSTEM_PROMPT}]
        for msg in conv.messages:
            history.append({"role": msg.role, "content": msg.content})
        history.append({"role": "user", "content": content})

        full_response = ""
        async for chunk in self._provider.stream_chat(messages=history, model=conv.model):
            full_response += chunk
            yield chunk

        # Save the complete response after streaming
        await self._repo.add_message(
            conversation_id,
            role="assistant",
            content=full_response,
            model=conv.model,
        )

    async def delete_conversation(self, conversation_id: str, user_id: str) -> None:
        conv = await self._repo.get_by_id(conversation_id)
        if conv.user_id != user_id:
            raise AuthorizationError("You do not have access to this conversation.")
        await self._repo.delete(conversation_id)

    @staticmethod
    def _serialize_conversation(conv: any, include_messages: bool = False) -> dict:
        data = {
            "id": conv.id,
            "title": conv.title,
            "model": conv.model,
            "created_at": conv.created_at.isoformat(),
            "updated_at": conv.updated_at.isoformat(),
        }
        if include_messages and hasattr(conv, "messages"):
            data["messages"] = [
                {
                    "id": m.id,
                    "role": m.role,
                    "content": m.content,
                    "model": m.model,
                    "tokens_used": m.tokens_used,
                    "created_at": m.created_at.isoformat(),
                }
                for m in conv.messages
            ]
        return data
