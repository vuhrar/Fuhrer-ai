"""
Fuhrer Backend — Application Cache Manager.
Wraps the kernel cache backend with domain-specific helpers.
"""
from typing import Any

from kernel.cache import CacheBackend, InMemoryCache, RedisCache
from kernel.config import settings, Environment
from kernel.logging import get_logger

logger = get_logger(__name__)

_cache: CacheBackend | None = None


def get_cache() -> CacheBackend:
    """Return the configured cache backend (singleton)."""
    global _cache
    if _cache is None:
        if settings.environment == Environment.TESTING:
            _cache = InMemoryCache(default_ttl=settings.cache_ttl_seconds)
            logger.info("Cache: using InMemoryCache (testing mode)")
        else:
            _cache = RedisCache(
                redis_url=settings.redis_url,
                max_connections=settings.redis_max_connections,
                default_ttl=settings.cache_ttl_seconds,
            )
            logger.info(f"Cache: using Redis at {settings.redis_url}")
    return _cache


# ─── Domain-specific cache helpers ────────────────────────────────────────────

async def cache_user(user_id: str, user_data: dict[str, Any]) -> None:
    await get_cache().set(f"user:{user_id}", user_data, ttl=300)


async def get_cached_user(user_id: str) -> dict[str, Any] | None:
    return await get_cache().get(f"user:{user_id}")


async def invalidate_user_cache(user_id: str) -> None:
    await get_cache().delete(f"user:{user_id}")


async def cache_conversation_list(user_id: str, data: list) -> None:
    await get_cache().set(f"conversations:{user_id}", data, ttl=120)


async def get_cached_conversation_list(user_id: str) -> list | None:
    return await get_cache().get(f"conversations:{user_id}")


async def invalidate_conversation_cache(user_id: str) -> None:
    await get_cache().clear_pattern(f"conversations:{user_id}*")
