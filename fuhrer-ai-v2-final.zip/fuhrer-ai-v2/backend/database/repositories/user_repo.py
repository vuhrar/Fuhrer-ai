"""User Repository."""
from sqlalchemy.ext.asyncio import AsyncSession

from backend.database.models.user import User
from kernel.exceptions import ConflictError

from .base import BaseRepository


class UserRepository(BaseRepository[User]):
    def __init__(self, session: AsyncSession) -> None:
        super().__init__(User, session)

    async def get_by_email(self, email: str) -> User | None:
        return await self.get_by_field("email", email)

    async def get_by_username(self, username: str) -> User | None:
        return await self.get_by_field("username", username)

    async def create_user(
        self,
        username: str,
        email: str,
        hashed_password: str,
        full_name: str | None = None,
    ) -> User:
        # Check uniqueness
        if await self.get_by_email(email):
            raise ConflictError(f"Email '{email}' is already registered.")
        if await self.get_by_username(username):
            raise ConflictError(f"Username '{username}' is already taken.")
        return await self.create(
            username=username,
            email=email,
            hashed_password=hashed_password,
            full_name=full_name,
        )
