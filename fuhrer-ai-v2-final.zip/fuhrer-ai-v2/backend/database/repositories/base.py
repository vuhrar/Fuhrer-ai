"""
Generic Async Repository Pattern.
Provides CRUD operations for any SQLAlchemy model.
"""
from typing import Any, Generic, TypeVar

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.database.base import Base
from kernel.exceptions import NotFoundError

ModelT = TypeVar("ModelT", bound=Base)


class BaseRepository(Generic[ModelT]):
    """Generic async repository providing standard CRUD operations."""

    def __init__(self, model: type[ModelT], session: AsyncSession) -> None:
        self._model = model
        self._session = session

    async def get_by_id(self, record_id: str) -> ModelT:
        result = await self._session.get(self._model, record_id)
        if result is None:
            raise NotFoundError(self._model.__name__, record_id)
        return result

    async def get_by_field(self, field: str, value: Any) -> ModelT | None:
        stmt = select(self._model).where(getattr(self._model, field) == value)
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()

    async def list_all(self, limit: int = 100, offset: int = 0) -> list[ModelT]:
        stmt = select(self._model).limit(limit).offset(offset)
        result = await self._session.execute(stmt)
        return list(result.scalars().all())

    async def create(self, **kwargs: Any) -> ModelT:
        instance = self._model(**kwargs)
        self._session.add(instance)
        await self._session.flush()
        await self._session.refresh(instance)
        return instance

    async def update(self, record_id: str, **kwargs: Any) -> ModelT:
        instance = await self.get_by_id(record_id)
        for key, value in kwargs.items():
            setattr(instance, key, value)
        await self._session.flush()
        await self._session.refresh(instance)
        return instance

    async def delete(self, record_id: str) -> None:
        instance = await self.get_by_id(record_id)
        await self._session.delete(instance)
        await self._session.flush()

    async def count(self) -> int:
        from sqlalchemy import func
        stmt = select(func.count()).select_from(self._model)
        result = await self._session.execute(stmt)
        return result.scalar_one()
