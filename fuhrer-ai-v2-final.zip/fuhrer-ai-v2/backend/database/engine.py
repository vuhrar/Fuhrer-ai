"""
Fuhrer Backend — Async SQLAlchemy Engine.
Uses create_async_engine to avoid blocking the FastAPI event loop.
"""
from sqlalchemy.ext.asyncio import AsyncEngine, create_async_engine

from kernel.config import settings
from kernel.logging import get_logger

logger = get_logger(__name__)


def build_engine() -> AsyncEngine:
    """Build and configure the async SQLAlchemy engine."""
    kwargs: dict = {
        "echo": settings.debug,
        "future": True,
    }

    # SQLite does not support connection pooling parameters
    if not settings.is_sqlite:
        kwargs.update(
            {
                "pool_size": settings.database_pool_size,
                "max_overflow": settings.database_max_overflow,
                "pool_timeout": settings.database_pool_timeout,
                "pool_recycle": settings.database_pool_recycle,
                "pool_pre_ping": True,
            }
        )
    else:
        # SQLite-specific: allow concurrent access in async context
        kwargs["connect_args"] = {"check_same_thread": False}

    logger.info(f"Building database engine for: {settings.database_url.split('///')[0]}")
    return create_async_engine(settings.database_url, **kwargs)


engine: AsyncEngine = build_engine()
