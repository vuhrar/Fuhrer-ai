"""
FastAPI authentication dependencies.
Used with Depends() to protect routes.
"""
from fastapi import Depends
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from backend.database.models.user import User
from backend.database.repositories.user_repo import UserRepository
from backend.database.session import get_db_session
from kernel.exceptions import AuthenticationError, AuthorizationError
from kernel.security import get_subject_from_token

from sqlalchemy.ext.asyncio import AsyncSession

_bearer = HTTPBearer(auto_error=False)


async def get_current_user(
    credentials: HTTPAuthorizationCredentials | None = Depends(_bearer),
    session: AsyncSession = Depends(get_db_session),
) -> User:
    """Extract and validate the current user from the Bearer token."""
    if credentials is None:
        raise AuthenticationError("Authorization header is missing.")

    user_id = get_subject_from_token(credentials.credentials)
    repo = UserRepository(session)
    user = await repo.get_by_id(user_id)

    if not user.is_active:
        raise AuthenticationError("Account is disabled.")

    return user


async def get_current_superuser(
    current_user: User = Depends(get_current_user),
) -> User:
    """Require superuser privileges."""
    if not current_user.is_superuser:
        raise AuthorizationError("Superuser privileges required.")
    return current_user
