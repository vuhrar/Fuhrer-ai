"""API v1 Routers."""
from .auth import router as auth_router
from .chat import router as chat_router
from .health import router as health_router
from .plugins import router as plugins_router

__all__ = ["auth_router", "chat_router", "health_router", "plugins_router"]
