"""Health Check API Router."""
from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse

from backend.core.cache_manager import get_cache
from backend.database.session import AsyncSessionFactory
from kernel.config import settings
from kernel.health import HealthStatus, get_full_health

router = APIRouter(prefix="/health", tags=["Health"])


@router.get("")
async def health_check() -> JSONResponse:
    """Quick liveness probe — returns 200 if the server is running."""
    return JSONResponse({"status": "healthy", "version": settings.app_version})


@router.get("/detailed")
async def detailed_health() -> JSONResponse:
    """
    Full health report including database, cache, and AI provider status.
    Returns 200 if healthy, 503 if any critical component is unhealthy.
    """
    report = await get_full_health(
        version=settings.app_version,
        session_factory=AsyncSessionFactory,
        cache=get_cache(),
        ollama_url=settings.ollama_url,
    )

    response_data = {
        "status": report.status,
        "version": report.version,
        "uptime_seconds": report.uptime_seconds,
        "components": [
            {
                "name": c.name,
                "status": c.status,
                "latency_ms": c.latency_ms,
                "details": c.details,
                "error": c.error,
            }
            for c in report.components
        ],
        "system": report.system_metrics,
    }

    status_code = 200 if report.status != HealthStatus.UNHEALTHY else 503
    return JSONResponse(response_data, status_code=status_code)


@router.get("/models")
async def list_ai_models() -> JSONResponse:
    """List available AI models from the Ollama provider."""
    from backend.services.ai.ollama_provider import ollama
    try:
        models = await ollama.list_models()
        return JSONResponse({"models": models, "default": settings.ollama_default_model})
    except Exception as exc:
        return JSONResponse({"models": [], "error": str(exc)}, status_code=503)
