"""Chat API Router — Conversations and AI messaging."""
from fastapi import APIRouter, Depends, status
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession

from backend.api.v1.dependencies.auth import get_current_user
from backend.api.v1.schemas.chat import (
    ConversationListResponse,
    ConversationResponse,
    CreateConversationRequest,
    MessageResponse,
    SendMessageRequest,
)
from backend.database.session import get_db_session
from backend.services.chat.service import ChatService

router = APIRouter(prefix="/chat", tags=["Chat"])


@router.post("/conversations", response_model=ConversationResponse, status_code=status.HTTP_201_CREATED)
async def create_conversation(
    body: CreateConversationRequest,
    current_user=Depends(get_current_user),
    session: AsyncSession = Depends(get_db_session),
) -> ConversationResponse:
    """Create a new conversation."""
    service = ChatService(session)
    data = await service.create_conversation(
        user_id=current_user.id,
        title=body.title,
        model=body.model,
    )
    return ConversationResponse(**data)


@router.get("/conversations", response_model=ConversationListResponse)
async def list_conversations(
    current_user=Depends(get_current_user),
    session: AsyncSession = Depends(get_db_session),
) -> ConversationListResponse:
    """List all conversations for the current user."""
    service = ChatService(session)
    convs = await service.list_conversations(current_user.id)
    return ConversationListResponse(conversations=[ConversationResponse(**c) for c in convs], total=len(convs))


@router.get("/conversations/{conversation_id}", response_model=ConversationResponse)
async def get_conversation(
    conversation_id: str,
    current_user=Depends(get_current_user),
    session: AsyncSession = Depends(get_db_session),
) -> ConversationResponse:
    """Get a conversation with its full message history."""
    service = ChatService(session)
    data = await service.get_conversation(conversation_id, current_user.id)
    return ConversationResponse(**data)


@router.delete("/conversations/{conversation_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_conversation(
    conversation_id: str,
    current_user=Depends(get_current_user),
    session: AsyncSession = Depends(get_db_session),
) -> None:
    """Delete a conversation and all its messages."""
    service = ChatService(session)
    await service.delete_conversation(conversation_id, current_user.id)


@router.post("/conversations/{conversation_id}/messages", response_model=MessageResponse)
async def send_message(
    conversation_id: str,
    body: SendMessageRequest,
    current_user=Depends(get_current_user),
    session: AsyncSession = Depends(get_db_session),
) -> MessageResponse:
    """Send a message and receive an AI response."""
    service = ChatService(session)
    result = await service.send_message(conversation_id, current_user.id, body.content)
    return MessageResponse(**result)


@router.post("/conversations/{conversation_id}/messages/stream")
async def stream_message(
    conversation_id: str,
    body: SendMessageRequest,
    current_user=Depends(get_current_user),
    session: AsyncSession = Depends(get_db_session),
) -> StreamingResponse:
    """Stream an AI response token by token (Server-Sent Events)."""
    service = ChatService(session)

    async def generate():
        async for chunk in service.stream_message(conversation_id, current_user.id, body.content):
            yield f"data: {chunk}\n\n"
        yield "data: [DONE]\n\n"

    return StreamingResponse(generate(), media_type="text/event-stream")
