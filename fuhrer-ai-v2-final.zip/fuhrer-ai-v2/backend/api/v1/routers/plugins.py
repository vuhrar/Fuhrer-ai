"""Plugin Management API Router."""
from fastapi import APIRouter, Depends

from backend.api.v1.dependencies.auth import get_current_superuser
from kernel.plugins import plugin_registry

router = APIRouter(prefix="/plugins", tags=["Plugins"])


@router.get("")
async def list_plugins(
    _=Depends(get_current_superuser),
) -> dict:
    """List all registered plugins (superuser only)."""
    plugins = plugin_registry.list_plugins()
    return {
        "plugins": [
            {
                "name": p.name,
                "version": p.version,
                "description": p.description,
                "author": p.author,
                "dependencies": p.dependencies,
            }
            for p in plugins
        ],
        "total": len(plugins),
    }
