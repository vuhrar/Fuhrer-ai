"""Auth API Schemas."""
import re

from pydantic import BaseModel, EmailStr, Field, field_validator


class RegisterRequest(BaseModel):
    username: str = Field(min_length=3, max_length=64, examples=["john_doe"])
    email: EmailStr = Field(examples=["john@example.com"])
    password: str = Field(min_length=8, max_length=128, examples=["SecurePass123!"])
    full_name: str | None = Field(default=None, max_length=128, examples=["John Doe"])

    @field_validator("username")
    @classmethod
    def validate_username(cls, v: str) -> str:
        if not re.match(r"^[a-zA-Z0-9_-]+$", v):
            raise ValueError("Username may only contain letters, digits, underscores, and hyphens.")
        return v.lower()

    @field_validator("password")
    @classmethod
    def validate_password_strength(cls, v: str) -> str:
        if not re.search(r"[A-Z]", v):
            raise ValueError("Password must contain at least one uppercase letter.")
        if not re.search(r"[0-9]", v):
            raise ValueError("Password must contain at least one digit.")
        return v


class LoginRequest(BaseModel):
    username_or_email: str = Field(examples=["john_doe"])
    password: str = Field(examples=["SecurePass123!"])


class RefreshRequest(BaseModel):
    refresh_token: str


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class UserResponse(BaseModel):
    id: str
    username: str
    email: str
    full_name: str | None
    is_active: bool
    is_superuser: bool
    created_at: str

    model_config = {"from_attributes": True}
