"""Chat API Schemas."""
from pydantic import BaseModel, Field


class CreateConversationRequest(BaseModel):
    title: str = Field(default="New Conversation", max_length=255)
    model: str | None = Field(default=None, examples=["llama3", "mistral"])


class SendMessageRequest(BaseModel):
    content: str = Field(min_length=1, max_length=32000, examples=["What is the capital of France?"])


class MessageResponse(BaseModel):
    id: str
    role: str
    content: str
    model: str | None
    tokens_used: int | None
    created_at: str


class ConversationResponse(BaseModel):
    id: str
    title: str
    model: str
    created_at: str
    updated_at: str
    messages: list[MessageResponse] | None = None


class ConversationListResponse(BaseModel):
    conversations: list[ConversationResponse]
    total: int
