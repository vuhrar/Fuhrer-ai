"""
Fuhrer Backend — Main Application Entry Point.
Production-grade FastAPI application with:
  - CORS protection
  - Rate limiting (SlowAPI)
  - Security headers
  - Request logging
  - Structured error handling
  - Async database initialization
  - Plugin system
"""
from contextlib import asynccontextmanager
from typing import Any

import orjson
from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.util import get_remote_address

from backend.api.v1.routers import auth_router, chat_router, health_router, plugins_router
from backend.database.base import Base
from backend.database.engine import engine
from backend.middleware.logging import RequestLoggingMiddleware
from backend.middleware.security import SecurityHeadersMiddleware
from kernel.config import settings
from kernel.exceptions import (
    AuthenticationError,
    AuthorizationError,
    ConflictError,
    FuhrerError,
    NotFoundError,
    RateLimitError,
    ValidationError,
)
from kernel.logging import configure_logging, get_logger

# ─── Logging ─────────────────────────────────────────────────────────────────
configure_logging(
    level=settings.log_level,
    rotation=settings.log_file_rotation,
    retention=settings.log_file_retention,
    diagnose=settings.debug,
)
logger = get_logger(__name__)

# ─── Rate Limiter ─────────────────────────────────────────────────────────────
limiter = Limiter(key_func=get_remote_address, default_limits=[f"{settings.rate_limit_per_minute}/minute"])


# ─── Lifespan ─────────────────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info(f"🚀 {settings.app_name} v{settings.app_version} starting [{settings.environment}]")

    # Create all database tables (for development/testing; use Alembic in production)
    if settings.environment.is_debug:
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        logger.info("✅ Database tables initialized")

    logger.info(f"✅ {settings.app_name} is ready to serve requests")
    yield

    logger.info(f"🛑 {settings.app_name} shutting down...")
    await engine.dispose()
    logger.info("✅ Database connections closed")


# ─── Application Factory ──────────────────────────────────────────────────────
def create_app() -> FastAPI:
    app = FastAPI(
        title=f"{settings.app_name} API",
        version=settings.app_version,
        description=(
            "Fuhrer AI — Production-grade Local AI Assistant. "
            "Privacy-first, offline-capable, plugin-based."
        ),
        docs_url="/docs" if settings.debug else None,
        redoc_url="/redoc" if settings.debug else None,
        openapi_url="/openapi.json" if settings.debug else None,
        lifespan=lifespan,
        default_response_class=_ORJSONResponse,
    )

    # ─── Rate Limiting ────────────────────────────────────────────────────────
    app.state.limiter = limiter
    app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

    # ─── CORS ─────────────────────────────────────────────────────────────────
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=settings.cors_allow_credentials,
        allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
        allow_headers=["Authorization", "Content-Type", "X-Request-ID"],
        expose_headers=["X-Request-ID", "X-Response-Time"],
    )

    # ─── Custom Middleware ────────────────────────────────────────────────────
    app.add_middleware(SecurityHeadersMiddleware)
    app.add_middleware(RequestLoggingMiddleware)

    # ─── Exception Handlers ──────────────────────────────────────────────────
    _register_exception_handlers(app)

    # ─── Routers ─────────────────────────────────────────────────────────────
    prefix = settings.api_prefix
    app.include_router(health_router, prefix=prefix)
    app.include_router(auth_router, prefix=prefix)
    app.include_router(chat_router, prefix=prefix)
    app.include_router(plugins_router, prefix=prefix)

    # ─── Root ─────────────────────────────────────────────────────────────────
    @app.get("/", include_in_schema=False)
    async def root() -> dict[str, Any]:
        return {
            "application": settings.app_name,
            "version": settings.app_version,
            "environment": settings.environment,
            "docs": "/docs" if settings.debug else "disabled",
            "health": f"{prefix}/health",
        }

    return app


def _register_exception_handlers(app: FastAPI) -> None:
    """Register unified exception handlers for all FuhrerError subtypes."""

    @app.exception_handler(NotFoundError)
    async def not_found_handler(request: Request, exc: NotFoundError) -> JSONResponse:
        return _error_response(exc.status_code, exc.error_code, exc.message)

    @app.exception_handler(AuthenticationError)
    async def auth_error_handler(request: Request, exc: AuthenticationError) -> JSONResponse:
        return _error_response(exc.status_code, exc.error_code, exc.message)

    @app.exception_handler(AuthorizationError)
    async def authz_error_handler(request: Request, exc: AuthorizationError) -> JSONResponse:
        return _error_response(exc.status_code, exc.error_code, exc.message)

    @app.exception_handler(ConflictError)
    async def conflict_handler(request: Request, exc: ConflictError) -> JSONResponse:
        return _error_response(exc.status_code, exc.error_code, exc.message)

    @app.exception_handler(ValidationError)
    async def validation_handler(request: Request, exc: ValidationError) -> JSONResponse:
        return _error_response(exc.status_code, exc.error_code, exc.message)

    @app.exception_handler(FuhrerError)
    async def fuhrer_error_handler(request: Request, exc: FuhrerError) -> JSONResponse:
        logger.error(f"Unhandled FuhrerError: {exc!r}")
        return _error_response(exc.status_code, exc.error_code, exc.message)

    @app.exception_handler(Exception)
    async def generic_error_handler(request: Request, exc: Exception) -> JSONResponse:
        logger.exception(f"Unhandled exception: {exc!r}")
        return _error_response(
            status.HTTP_500_INTERNAL_SERVER_ERROR,
            "INTERNAL_ERROR",
            "An unexpected error occurred." if not settings.debug else str(exc),
        )


def _error_response(status_code: int, error_code: str, message: str) -> JSONResponse:
    return JSONResponse(
        status_code=status_code,
        content={"error": error_code, "message": message},
    )


class _ORJSONResponse(JSONResponse):
    """High-performance JSON responses using orjson."""

    def render(self, content: Any) -> bytes:
        return orjson.dumps(content, option=orjson.OPT_NON_STR_KEYS | orjson.OPT_SERIALIZE_NUMPY)


# ─── Application Instance ─────────────────────────────────────────────────────
app = create_app()
