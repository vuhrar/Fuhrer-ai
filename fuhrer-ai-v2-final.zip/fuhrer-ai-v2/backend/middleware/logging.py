"""
Fuhrer Backend — Request/Response Logging Middleware.
Logs every request with timing, status, and correlation ID.
"""
import time
import uuid

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware

from kernel.logging import get_logger

logger = get_logger(__name__)


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """Logs all incoming requests with timing and correlation IDs."""

    async def dispatch(self, request: Request, call_next: any) -> Response:
        request_id = str(uuid.uuid4())[:8]
        start = time.monotonic()

        # Attach request ID to request state for downstream use
        request.state.request_id = request_id

        response = await call_next(request)

        duration_ms = round((time.monotonic() - start) * 1000, 2)
        status = response.status_code

        log_fn = logger.info if status < 400 else logger.warning if status < 500 else logger.error
        log_fn(
            f"[{request_id}] {request.method} {request.url.path} "
            f"→ {status} ({duration_ms}ms)"
        )

        response.headers["X-Request-ID"] = request_id
        response.headers["X-Response-Time"] = f"{duration_ms}ms"
        return response
