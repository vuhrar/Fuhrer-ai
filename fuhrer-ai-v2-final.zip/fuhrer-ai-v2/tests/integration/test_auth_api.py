"""Integration tests for the Authentication API."""
import pytest
from httpx import AsyncClient


@pytest.mark.asyncio
class TestRegister:
    async def test_register_success(self, client: AsyncClient):
        response = await client.post("/api/v1/auth/register", json={
            "username": "newuser",
            "email": "newuser@example.com",
            "password": "ValidPass123!",
        })
        assert response.status_code == 201
        data = response.json()
        assert "access_token" in data
        assert "refresh_token" in data
        assert data["token_type"] == "bearer"

    async def test_register_duplicate_email(self, client: AsyncClient):
        payload = {
            "username": "user1",
            "email": "dup@example.com",
            "password": "ValidPass123!",
        }
        await client.post("/api/v1/auth/register", json=payload)
        # Second registration with same email
        payload["username"] = "user2"
        response = await client.post("/api/v1/auth/register", json=payload)
        assert response.status_code == 409

    async def test_register_duplicate_username(self, client: AsyncClient):
        payload = {
            "username": "sameuser",
            "email": "a@example.com",
            "password": "ValidPass123!",
        }
        await client.post("/api/v1/auth/register", json=payload)
        payload["email"] = "b@example.com"
        response = await client.post("/api/v1/auth/register", json=payload)
        assert response.status_code == 409

    async def test_register_weak_password(self, client: AsyncClient):
        response = await client.post("/api/v1/auth/register", json={
            "username": "weakuser",
            "email": "weak@example.com",
            "password": "short",
        })
        assert response.status_code == 422

    async def test_register_invalid_email(self, client: AsyncClient):
        response = await client.post("/api/v1/auth/register", json={
            "username": "badmail",
            "email": "not-an-email",
            "password": "ValidPass123!",
        })
        assert response.status_code == 422


@pytest.mark.asyncio
class TestLogin:
    async def test_login_success(self, client: AsyncClient, registered_user: dict):
        response = await client.post("/api/v1/auth/login", json={
            "username_or_email": "testuser",
            "password": "TestPass123!",
        })
        assert response.status_code == 200
        assert "access_token" in response.json()

    async def test_login_with_email(self, client: AsyncClient, registered_user: dict):
        response = await client.post("/api/v1/auth/login", json={
            "username_or_email": "test@example.com",
            "password": "TestPass123!",
        })
        assert response.status_code == 200

    async def test_login_wrong_password(self, client: AsyncClient, registered_user: dict):
        response = await client.post("/api/v1/auth/login", json={
            "username_or_email": "testuser",
            "password": "WrongPass123!",
        })
        assert response.status_code == 401

    async def test_login_nonexistent_user(self, client: AsyncClient):
        response = await client.post("/api/v1/auth/login", json={
            "username_or_email": "ghost",
            "password": "SomePass123!",
        })
        assert response.status_code == 401


@pytest.mark.asyncio
class TestTokenRefresh:
    async def test_refresh_success(self, client: AsyncClient, registered_user: dict):
        response = await client.post("/api/v1/auth/refresh", json={
            "refresh_token": registered_user["refresh_token"],
        })
        assert response.status_code == 200
        assert "access_token" in response.json()

    async def test_refresh_invalid_token(self, client: AsyncClient):
        response = await client.post("/api/v1/auth/refresh", json={
            "refresh_token": "invalid.token.here",
        })
        assert response.status_code == 401


@pytest.mark.asyncio
class TestGetMe:
    async def test_get_me_authenticated(self, client: AsyncClient, auth_headers: dict):
        response = await client.get("/api/v1/auth/me", headers=auth_headers)
        assert response.status_code == 200
        data = response.json()
        assert data["username"] == "testuser"
        assert data["email"] == "test@example.com"

    async def test_get_me_unauthenticated(self, client: AsyncClient):
        response = await client.get("/api/v1/auth/me")
        assert response.status_code == 401

    async def test_get_me_invalid_token(self, client: AsyncClient):
        response = await client.get(
            "/api/v1/auth/me",
            headers={"Authorization": "Bearer invalid.token"},
        )
        assert response.status_code == 401
