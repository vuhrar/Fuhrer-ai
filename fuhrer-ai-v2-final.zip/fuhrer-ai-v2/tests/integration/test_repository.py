"""Integration tests for database repositories."""
import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from backend.database.repositories.conversation_repo import ConversationRepository
from backend.database.repositories.user_repo import UserRepository
from kernel.exceptions import ConflictError, NotFoundError
from kernel.security import hash_password


@pytest.mark.asyncio
class TestUserRepository:
    async def test_create_user(self, db_session: AsyncSession):
        repo = UserRepository(db_session)
        user = await repo.create_user(
            username="repouser",
            email="repo@example.com",
            hashed_password=hash_password("pass"),
        )
        assert user.id is not None
        assert user.username == "repouser"

    async def test_get_by_email(self, db_session: AsyncSession):
        repo = UserRepository(db_session)
        await repo.create_user("u1", "u1@test.com", hash_password("pass"))
        user = await repo.get_by_email("u1@test.com")
        assert user is not None
        assert user.username == "u1"

    async def test_get_by_username(self, db_session: AsyncSession):
        repo = UserRepository(db_session)
        await repo.create_user("u2", "u2@test.com", hash_password("pass"))
        user = await repo.get_by_username("u2")
        assert user is not None

    async def test_duplicate_email_raises(self, db_session: AsyncSession):
        repo = UserRepository(db_session)
        await repo.create_user("u3", "dup@test.com", hash_password("pass"))
        with pytest.raises(ConflictError):
            await repo.create_user("u4", "dup@test.com", hash_password("pass"))

    async def test_get_by_id_not_found(self, db_session: AsyncSession):
        repo = UserRepository(db_session)
        with pytest.raises(NotFoundError):
            await repo.get_by_id("nonexistent-id")

    async def test_update_user(self, db_session: AsyncSession):
        repo = UserRepository(db_session)
        user = await repo.create_user("u5", "u5@test.com", hash_password("pass"))
        updated = await repo.update(user.id, full_name="Updated Name")
        assert updated.full_name == "Updated Name"

    async def test_count(self, db_session: AsyncSession):
        repo = UserRepository(db_session)
        initial = await repo.count()
        await repo.create_user("cnt1", "cnt1@test.com", hash_password("pass"))
        await repo.create_user("cnt2", "cnt2@test.com", hash_password("pass"))
        assert await repo.count() == initial + 2


@pytest.mark.asyncio
class TestConversationRepository:
    async def _create_user(self, db_session: AsyncSession, suffix: str = "") -> str:
        repo = UserRepository(db_session)
        user = await repo.create_user(
            f"convuser{suffix}", f"conv{suffix}@test.com", hash_password("pass")
        )
        return user.id

    async def test_create_conversation(self, db_session: AsyncSession):
        user_id = await self._create_user(db_session, "1")
        repo = ConversationRepository(db_session)
        conv = await repo.create(user_id=user_id, title="Test Chat", model="llama3")
        assert conv.id is not None
        assert conv.title == "Test Chat"

    async def test_get_user_conversations(self, db_session: AsyncSession):
        user_id = await self._create_user(db_session, "2")
        repo = ConversationRepository(db_session)
        await repo.create(user_id=user_id, title="Chat 1", model="llama3")
        await repo.create(user_id=user_id, title="Chat 2", model="mistral")
        convs = await repo.get_user_conversations(user_id)
        assert len(convs) == 2

    async def test_add_message(self, db_session: AsyncSession):
        user_id = await self._create_user(db_session, "3")
        repo = ConversationRepository(db_session)
        conv = await repo.create(user_id=user_id, title="Chat", model="llama3")
        msg = await repo.add_message(conv.id, role="user", content="Hello!")
        assert msg.id is not None
        assert msg.role == "user"
        assert msg.content == "Hello!"

    async def test_get_with_messages(self, db_session: AsyncSession):
        user_id = await self._create_user(db_session, "4")
        repo = ConversationRepository(db_session)
        conv = await repo.create(user_id=user_id, title="Chat", model="llama3")
        await repo.add_message(conv.id, role="user", content="Hi")
        await repo.add_message(conv.id, role="assistant", content="Hello!")
        full_conv = await repo.get_with_messages(conv.id)
        assert full_conv is not None
        assert len(full_conv.messages) == 2
