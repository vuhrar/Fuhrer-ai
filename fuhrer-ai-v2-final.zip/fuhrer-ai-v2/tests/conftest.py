"""
Fuhrer Test Suite — Shared Fixtures.
Uses in-memory SQLite for fast, isolated tests.
"""
import asyncio
import os
from collections.abc import AsyncGenerator
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

# ─── Force testing environment BEFORE importing anything else ─────────────────
os.environ.setdefault("ENVIRONMENT", "testing")
os.environ.setdefault("SECRET_KEY", "test-secret-key-that-is-long-enough-for-testing-purposes-123456")
os.environ.setdefault("DATABASE_URL", "sqlite+aiosqlite:///:memory:")

from backend.database.base import Base
from backend.database.session import get_db_session
from backend.main import create_app
from kernel.cache import InMemoryCache
from kernel.config import settings

# ─── Event Loop ───────────────────────────────────────────────────────────────
@pytest.fixture(scope="session")
def event_loop():
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


# ─── In-Memory Database ───────────────────────────────────────────────────────
TEST_DATABASE_URL = "sqlite+aiosqlite:///:memory:"

@pytest_asyncio.fixture(scope="session")
async def test_engine():
    engine = create_async_engine(
        TEST_DATABASE_URL,
        connect_args={"check_same_thread": False},
    )
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield engine
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
    await engine.dispose()


@pytest_asyncio.fixture
async def db_session(test_engine) -> AsyncGenerator[AsyncSession, None]:
    """Provide a transactional test session that rolls back after each test."""
    factory = async_sessionmaker(
        bind=test_engine,
        class_=AsyncSession,
        autoflush=False,
        autocommit=False,
        expire_on_commit=False,
    )
    async with factory() as session:
        yield session
        await session.rollback()


# ─── Test Client ──────────────────────────────────────────────────────────────
@pytest_asyncio.fixture
async def client(db_session: AsyncSession) -> AsyncGenerator[AsyncClient, None]:
    """Provide an async HTTP test client with DB session override."""
    app = create_app()

    async def override_db():
        yield db_session

    app.dependency_overrides[get_db_session] = override_db

    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://test",
    ) as ac:
        yield ac

    app.dependency_overrides.clear()


# ─── Auth Helpers ─────────────────────────────────────────────────────────────
@pytest_asyncio.fixture
async def registered_user(client: AsyncClient) -> dict[str, Any]:
    """Register a test user and return the token response."""
    response = await client.post("/api/v1/auth/register", json={
        "username": "testuser",
        "email": "test@example.com",
        "password": "TestPass123!",
        "full_name": "Test User",
    })
    assert response.status_code == 201
    return response.json()


@pytest_asyncio.fixture
async def auth_headers(registered_user: dict) -> dict[str, str]:
    """Return Authorization headers for the test user."""
    return {"Authorization": f"Bearer {registered_user['access_token']}"}


# ─── Mock AI Provider ─────────────────────────────────────────────────────────
@pytest.fixture
def mock_ollama():
    """Mock OllamaProvider to avoid real HTTP calls in tests."""
    mock = AsyncMock()
    mock.chat.return_value = {
        "content": "This is a test AI response.",
        "model": "llama3",
        "tokens_used": 42,
        "done": True,
    }
    mock.list_models.return_value = ["llama3", "mistral", "phi3"]
    mock.is_available.return_value = True
    return mock


# ─── In-Memory Cache ──────────────────────────────────────────────────────────
@pytest.fixture
def memory_cache() -> InMemoryCache:
    cache = InMemoryCache(default_ttl=60)
    yield cache
    cache.clear_all()
