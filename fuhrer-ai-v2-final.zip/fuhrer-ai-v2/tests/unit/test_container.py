"""Unit tests for the DI Container."""
import pytest

from kernel.container import Container, ServiceLifetime
from kernel.exceptions import ConflictError, NotFoundError


class TestContainer:
    def setup_method(self):
        self.container = Container()

    def test_register_and_resolve_singleton(self):
        service = object()
        self.container.singleton("my_service", service)
        resolved = self.container.resolve("my_service")
        assert resolved is service

    def test_resolve_missing_raises(self):
        with pytest.raises(NotFoundError):
            self.container.resolve("nonexistent")

    def test_duplicate_singleton_raises(self):
        self.container.singleton("svc", object())
        with pytest.raises(ConflictError):
            self.container.singleton("svc", object())

    def test_override_replaces_service(self):
        original = object()
        replacement = object()
        self.container.singleton("svc", original)
        self.container.override("svc", replacement)
        assert self.container.resolve("svc") is replacement

    def test_factory_singleton_caches(self):
        call_count = 0

        def factory():
            nonlocal call_count
            call_count += 1
            return object()

        self.container.register("svc", factory, ServiceLifetime.SINGLETON)
        r1 = self.container.resolve("svc")
        r2 = self.container.resolve("svc")
        assert r1 is r2
        assert call_count == 1

    def test_factory_transient_creates_new(self):
        self.container.register("svc", lambda: object(), ServiceLifetime.TRANSIENT)
        r1 = self.container.resolve("svc")
        r2 = self.container.resolve("svc")
        assert r1 is not r2

    def test_exists_returns_true(self):
        self.container.singleton("svc", object())
        assert self.container.exists("svc")

    def test_exists_returns_false(self):
        assert not self.container.exists("ghost")

    def test_clear_removes_all(self):
        self.container.singleton("svc", object())
        self.container.clear()
        assert not self.container.exists("svc")

    def test_registered_services_list(self):
        self.container.singleton("a", object())
        self.container.singleton("b", object())
        keys = self.container.registered_services
        assert "a" in keys
        assert "b" in keys
