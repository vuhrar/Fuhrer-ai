"""Unit tests for the exception hierarchy."""
import pytest

from kernel.exceptions import (
    AIProviderError,
    AuthenticationError,
    AuthorizationError,
    CacheError,
    ConflictError,
    DatabaseError,
    FuhrerError,
    ModelNotFoundError,
    NotFoundError,
    PluginNotFoundError,
    RateLimitError,
    TokenExpiredError,
    TokenInvalidError,
    ValidationError,
)


class TestFuhrerError:
    def test_base_exception_message(self):
        exc = FuhrerError("test message")
        assert exc.message == "test message"
        assert str(exc) == "test message"

    def test_default_message(self):
        exc = FuhrerError()
        assert "unexpected" in exc.message.lower()

    def test_repr(self):
        exc = FuhrerError("test")
        assert "FuhrerError" in repr(exc)

    def test_status_code(self):
        assert FuhrerError.status_code == 500

    def test_error_code(self):
        assert FuhrerError.error_code == "INTERNAL_ERROR"


class TestAuthExceptions:
    def test_authentication_error_defaults(self):
        exc = AuthenticationError()
        assert exc.status_code == 401
        assert exc.error_code == "AUTHENTICATION_ERROR"

    def test_authorization_error_defaults(self):
        exc = AuthorizationError()
        assert exc.status_code == 403
        assert exc.error_code == "AUTHORIZATION_ERROR"

    def test_token_expired(self):
        exc = TokenExpiredError()
        assert exc.error_code == "TOKEN_EXPIRED"
        assert exc.status_code == 401

    def test_token_invalid(self):
        exc = TokenInvalidError("bad token")
        assert exc.error_code == "TOKEN_INVALID"
        assert "bad token" in exc.message

    def test_inheritance_chain(self):
        exc = TokenExpiredError()
        assert isinstance(exc, AuthenticationError)
        assert isinstance(exc, FuhrerError)


class TestDomainExceptions:
    def test_not_found_with_resource(self):
        exc = NotFoundError("User", "123")
        assert "User" in exc.message
        assert "123" in exc.message
        assert exc.status_code == 404

    def test_not_found_without_id(self):
        exc = NotFoundError("Conversation")
        assert "Conversation" in exc.message
        assert exc.status_code == 404

    def test_conflict_error(self):
        exc = ConflictError("Already exists")
        assert exc.status_code == 409

    def test_validation_error(self):
        exc = ValidationError("Invalid input")
        assert exc.status_code == 422

    def test_rate_limit_error(self):
        exc = RateLimitError()
        assert exc.status_code == 429


class TestAIExceptions:
    def test_ai_provider_error(self):
        exc = AIProviderError("Ollama is down")
        assert exc.status_code == 502

    def test_model_not_found(self):
        exc = ModelNotFoundError("llama99")
        assert "llama99" in exc.message
        assert exc.error_code == "MODEL_NOT_FOUND"
        assert isinstance(exc, AIProviderError)


class TestPluginExceptions:
    def test_plugin_not_found(self):
        exc = PluginNotFoundError("my-plugin")
        assert "my-plugin" in exc.message
        assert exc.status_code == 404


class TestInfrastructureExceptions:
    def test_database_error(self):
        exc = DatabaseError("Connection failed")
        assert exc.status_code == 500

    def test_cache_error(self):
        exc = CacheError("Redis timeout")
        assert exc.status_code == 500
