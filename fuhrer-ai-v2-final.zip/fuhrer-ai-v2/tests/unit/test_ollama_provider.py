"""Unit tests for OllamaProvider using httpx mock."""
import json
import os
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

os.environ.setdefault("ENVIRONMENT", "testing")
os.environ.setdefault("SECRET_KEY", "test-secret-key-that-is-long-enough-for-testing-purposes-123456")

from kernel.exceptions import AIProviderError, ModelNotFoundError


class MockResponse:
    def __init__(self, status_code=200, json_data=None):
        self.status_code = status_code
        self._json = json_data or {}

    def json(self):
        return self._json

    def raise_for_status(self):
        if self.status_code >= 400:
            import httpx
            raise httpx.HTTPStatusError("error", request=MagicMock(), response=self)


@pytest.mark.asyncio
class TestOllamaProvider:
    def _make_provider(self):
        from backend.services.ai.ollama_provider import OllamaProvider
        return OllamaProvider(
            base_url="http://localhost:11434",
            default_model="llama3",
            timeout=10,
            max_retries=0,
        )

    async def test_list_models_success(self):
        provider = self._make_provider()
        mock_response = MockResponse(200, {"models": [{"name": "llama3"}, {"name": "mistral"}]})

        mock_client = AsyncMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=None)
        mock_client.get = AsyncMock(return_value=mock_response)

        with patch("backend.services.ai.ollama_provider.httpx.AsyncClient", return_value=mock_client):
            models = await provider.list_models()
            assert "llama3" in models
            assert "mistral" in models

    async def test_list_models_connection_error(self):
        import httpx
        provider = self._make_provider()

        mock_client = AsyncMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=None)
        mock_client.get = AsyncMock(side_effect=httpx.ConnectError("refused"))

        with patch("backend.services.ai.ollama_provider.httpx.AsyncClient", return_value=mock_client):
            with pytest.raises(AIProviderError):
                await provider.list_models()

    async def test_chat_success(self):
        provider = self._make_provider()
        mock_response = MockResponse(200, {
            "message": {"content": "Hello there!"},
            "model": "llama3",
            "eval_count": 15,
            "done": True,
        })

        mock_client = AsyncMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=None)
        mock_client.post = AsyncMock(return_value=mock_response)

        with patch("backend.services.ai.ollama_provider.httpx.AsyncClient", return_value=mock_client):
            result = await provider.chat([{"role": "user", "content": "Hi"}])
            assert result["content"] == "Hello there!"
            assert result["tokens_used"] == 15

    async def test_chat_model_not_found(self):
        provider = self._make_provider()
        mock_response = MockResponse(404)

        mock_client = AsyncMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=None)
        mock_client.post = AsyncMock(return_value=mock_response)

        with patch("backend.services.ai.ollama_provider.httpx.AsyncClient", return_value=mock_client):
            with pytest.raises(ModelNotFoundError):
                await provider.chat([{"role": "user", "content": "Hi"}], model="nonexistent")

    async def test_is_available_true(self):
        provider = self._make_provider()
        mock_response = MockResponse(200, {"models": []})

        mock_client = AsyncMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=None)
        mock_client.get = AsyncMock(return_value=mock_response)

        with patch("backend.services.ai.ollama_provider.httpx.AsyncClient", return_value=mock_client):
            assert await provider.is_available()

    async def test_is_available_false(self):
        import httpx
        provider = self._make_provider()

        mock_client = AsyncMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=None)
        mock_client.get = AsyncMock(side_effect=httpx.ConnectError("refused"))

        with patch("backend.services.ai.ollama_provider.httpx.AsyncClient", return_value=mock_client):
            assert not await provider.is_available()
