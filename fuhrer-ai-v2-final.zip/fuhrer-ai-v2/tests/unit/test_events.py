"""Unit tests for the Event Bus."""
import pytest

from kernel.events import Event, EventBus, EventHandler


class TestEvent:
    def test_create_event(self):
        event = Event.create("user.registered", {"user_id": "123"})
        assert event.name == "user.registered"
        assert event.payload["user_id"] == "123"
        assert event.id is not None
        assert event.created_at is not None

    def test_event_repr(self):
        event = Event.create("test.event")
        assert "test.event" in repr(event)

    def test_event_default_source(self):
        event = Event.create("test")
        assert event.source == "system"

    def test_event_custom_source(self):
        event = Event.create("test", source="auth-service")
        assert event.source == "auth-service"

    def test_unique_ids(self):
        e1 = Event.create("test")
        e2 = Event.create("test")
        assert e1.id != e2.id


class TestEventBus:
    def setup_method(self):
        self.bus = EventBus()

    @pytest.mark.asyncio
    async def test_publish_to_handler(self):
        received = []

        class MyHandler(EventHandler):
            async def handle(self, event: Event) -> None:
                received.append(event)

        self.bus.subscribe("test.event", MyHandler())
        event = Event.create("test.event", {"key": "value"})
        await self.bus.publish(event)

        assert len(received) == 1
        assert received[0].name == "test.event"

    @pytest.mark.asyncio
    async def test_publish_to_fn_handler(self):
        received = []

        @self.bus.on("test.fn")
        async def handler(event: Event) -> None:
            received.append(event)

        await self.bus.publish(Event.create("test.fn"))
        assert len(received) == 1

    @pytest.mark.asyncio
    async def test_multiple_handlers(self):
        count = []

        class H1(EventHandler):
            async def handle(self, event: Event) -> None:
                count.append(1)

        class H2(EventHandler):
            async def handle(self, event: Event) -> None:
                count.append(2)

        self.bus.subscribe("multi", H1())
        self.bus.subscribe("multi", H2())
        await self.bus.publish(Event.create("multi"))
        assert len(count) == 2

    @pytest.mark.asyncio
    async def test_handler_error_does_not_stop_others(self):
        """A failing handler must not prevent other handlers from running."""
        results = []

        class FailingHandler(EventHandler):
            async def handle(self, event: Event) -> None:
                raise RuntimeError("intentional failure")

        class SuccessHandler(EventHandler):
            async def handle(self, event: Event) -> None:
                results.append("success")

        self.bus.subscribe("test", FailingHandler())
        self.bus.subscribe("test", SuccessHandler())
        await self.bus.publish(Event.create("test"))
        assert "success" in results

    @pytest.mark.asyncio
    async def test_no_handlers_no_error(self):
        """Publishing to an event with no handlers should not raise."""
        await self.bus.publish(Event.create("unknown.event"))

    def test_unsubscribe(self):
        class H(EventHandler):
            async def handle(self, event: Event) -> None:
                pass

        handler = H()
        self.bus.subscribe("evt", handler)
        self.bus.unsubscribe("evt", handler)
        assert "evt" not in self.bus.subscribed_events or \
               handler not in self.bus._handlers.get("evt", [])

    def test_clear(self):
        @self.bus.on("evt")
        async def h(e): pass
        self.bus.clear()
        assert self.bus.subscribed_events == []
