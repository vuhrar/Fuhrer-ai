"""Unit tests for the logging module."""
from kernel.logging import configure_logging, get_logger, reset_logging


class TestLogging:
    def setup_method(self):
        reset_logging()

    def test_get_logger_returns_bound_logger(self):
        logger = get_logger("test.module")
        assert logger is not None

    def test_configure_logging_idempotent(self):
        """Calling configure_logging twice should not raise."""
        configure_logging(level="DEBUG")
        configure_logging(level="INFO")  # Should be a no-op

    def test_logger_can_log(self):
        configure_logging(level="DEBUG")
        logger = get_logger("test")
        # These should not raise
        logger.debug("debug message")
        logger.info("info message")
        logger.warning("warning message")
        logger.error("error message")

    def test_reset_allows_reconfiguration(self):
        configure_logging(level="INFO")
        reset_logging()
        configure_logging(level="DEBUG")  # Should work after reset
