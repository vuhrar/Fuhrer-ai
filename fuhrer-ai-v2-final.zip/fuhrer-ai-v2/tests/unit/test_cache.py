"""Unit tests for the cache abstraction (InMemoryCache)."""
import pytest

from kernel.cache import InMemoryCache


@pytest.mark.asyncio
class TestInMemoryCache:
    async def test_set_and_get(self):
        cache = InMemoryCache()
        await cache.set("key1", {"data": "value"})
        result = await cache.get("key1")
        assert result == {"data": "value"}

    async def test_get_missing_returns_none(self):
        cache = InMemoryCache()
        result = await cache.get("nonexistent")
        assert result is None

    async def test_delete(self):
        cache = InMemoryCache()
        await cache.set("key", "value")
        await cache.delete("key")
        assert await cache.get("key") is None

    async def test_exists_true(self):
        cache = InMemoryCache()
        await cache.set("key", "value")
        assert await cache.exists("key")

    async def test_exists_false(self):
        cache = InMemoryCache()
        assert not await cache.exists("missing")

    async def test_ping_returns_true(self):
        cache = InMemoryCache()
        assert await cache.ping()

    async def test_clear_pattern(self):
        cache = InMemoryCache()
        await cache.set("user:1", "a")
        await cache.set("user:2", "b")
        await cache.set("session:1", "c")
        deleted = await cache.clear_pattern("user:*")
        assert deleted == 2
        assert await cache.get("user:1") is None
        assert await cache.get("session:1") == "c"

    async def test_clear_all(self):
        cache = InMemoryCache()
        await cache.set("a", 1)
        await cache.set("b", 2)
        cache.clear_all()
        assert await cache.get("a") is None
        assert await cache.get("b") is None

    async def test_set_various_types(self):
        cache = InMemoryCache()
        await cache.set("int", 42)
        await cache.set("list", [1, 2, 3])
        await cache.set("dict", {"nested": True})
        assert await cache.get("int") == 42
        assert await cache.get("list") == [1, 2, 3]
        assert await cache.get("dict") == {"nested": True}
