"""Unit tests for Settings and Environment."""
import os
from unittest.mock import patch

import pytest

from kernel.config.environment import Environment
from kernel.config.settings import Settings


class TestEnvironment:
    def test_development_is_debug(self):
        assert Environment.DEVELOPMENT.is_debug

    def test_testing_is_debug(self):
        assert Environment.TESTING.is_debug

    def test_production_not_debug(self):
        assert not Environment.PRODUCTION.is_debug

    def test_production_is_production(self):
        assert Environment.PRODUCTION.is_production

    def test_development_not_production(self):
        assert not Environment.DEVELOPMENT.is_production


class TestSettings:
    def test_default_values(self):
        # Use patch to ensure environment variables don't interfere
        with patch.dict(os.environ, {"SECRET_KEY": "test-secret-key-12345678901234567890123456789012"}, clear=True):
            settings = Settings()
            assert settings.app_name == "Fuhrer"
            assert settings.app_version == "2.0.0"

    def test_is_sqlite_true(self):
        with patch.dict(os.environ, {
            "SECRET_KEY": "test-secret-key-12345678901234567890123456789012",
            "DATABASE_URL": "sqlite+aiosqlite:///./test.db"
        }, clear=True):
            settings = Settings()
            assert settings.is_sqlite

    def test_is_sqlite_false(self):
        with patch.dict(os.environ, {
            "SECRET_KEY": "test-secret-key-12345678901234567890123456789012",
            "DATABASE_URL": "postgresql+asyncpg://user:pass@localhost/db"
        }, clear=True):
            settings = Settings()
            assert not settings.is_sqlite

    def test_cors_origins_from_string(self):
        with patch.dict(os.environ, {
            "SECRET_KEY": "test-secret-key-12345678901234567890123456789012",
            "CORS_ORIGINS": '["http://localhost:3000","http://localhost:8080"]'
        }, clear=True):
            settings = Settings()
            assert "http://localhost:3000" in settings.cors_origins
            assert "http://localhost:8080" in settings.cors_origins

    def test_api_prefix(self):
        with patch.dict(os.environ, {"SECRET_KEY": "test-secret-key-12345678901234567890123456789012"}, clear=True):
            settings = Settings()
            assert settings.api_prefix == "/api/v1"
