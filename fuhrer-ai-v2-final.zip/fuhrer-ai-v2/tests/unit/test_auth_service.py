"""Unit tests for the AuthService."""
import os
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

os.environ.setdefault("ENVIRONMENT", "testing")
os.environ.setdefault("SECRET_KEY", "test-secret-key-that-is-long-enough-for-testing-purposes-123456")

from kernel.exceptions import AuthenticationError, ConflictError


class TestAuthServiceUnit:
    """Unit tests for AuthService using mocked repository."""

    def _make_user(self, **kwargs):
        from kernel.security import hash_password
        user = MagicMock()
        user.id = "user-id-123"
        user.username = kwargs.get("username", "testuser")
        user.email = kwargs.get("email", "test@example.com")
        user.hashed_password = hash_password(kwargs.get("password", "TestPass123!"))
        user.is_active = kwargs.get("is_active", True)
        user.full_name = kwargs.get("full_name", None)
        return user

    @pytest.mark.asyncio
    async def test_register_success(self):
        from backend.services.auth.service import AuthService
        session = AsyncMock()
        service = AuthService(session)

        mock_user = self._make_user()
        with patch.object(service._repo, "create_user", return_value=mock_user) as mock_create:
            result = await service.register("testuser", "test@example.com", "TestPass123!")
            assert "access_token" in result
            assert "refresh_token" in result
            mock_create.assert_called_once()

    @pytest.mark.asyncio
    async def test_login_success(self):
        from backend.services.auth.service import AuthService
        session = AsyncMock()
        service = AuthService(session)

        mock_user = self._make_user(password="TestPass123!")
        with patch.object(service._repo, "get_by_email", return_value=None), \
             patch.object(service._repo, "get_by_username", return_value=mock_user):
            result = await service.login("testuser", "TestPass123!")
            assert "access_token" in result

    @pytest.mark.asyncio
    async def test_login_wrong_password(self):
        from backend.services.auth.service import AuthService
        session = AsyncMock()
        service = AuthService(session)

        mock_user = self._make_user(password="CorrectPass123!")
        with patch.object(service._repo, "get_by_email", return_value=None), \
             patch.object(service._repo, "get_by_username", return_value=mock_user):
            with pytest.raises(AuthenticationError):
                await service.login("testuser", "WrongPass123!")

    @pytest.mark.asyncio
    async def test_login_user_not_found(self):
        from backend.services.auth.service import AuthService
        session = AsyncMock()
        service = AuthService(session)

        with patch.object(service._repo, "get_by_email", return_value=None), \
             patch.object(service._repo, "get_by_username", return_value=None):
            with pytest.raises(AuthenticationError):
                await service.login("ghost", "SomePass123!")

    @pytest.mark.asyncio
    async def test_login_inactive_user(self):
        from backend.services.auth.service import AuthService
        session = AsyncMock()
        service = AuthService(session)

        mock_user = self._make_user(is_active=False)
        with patch.object(service._repo, "get_by_email", return_value=None), \
             patch.object(service._repo, "get_by_username", return_value=mock_user):
            with pytest.raises(AuthenticationError):
                await service.login("testuser", "TestPass123!")

    @pytest.mark.asyncio
    async def test_refresh_success(self):
        from backend.services.auth.service import AuthService
        from kernel.security import create_refresh_token
        session = AsyncMock()
        service = AuthService(session)

        mock_user = self._make_user()
        refresh_token = create_refresh_token("user-id-123")
        with patch.object(service._repo, "get_by_id", return_value=mock_user):
            result = await service.refresh(refresh_token)
            assert "access_token" in result

    def test_build_token_response(self):
        from backend.services.auth.service import AuthService
        result = AuthService._build_token_response("user-1", "testuser")
        assert "access_token" in result
        assert "refresh_token" in result
        assert result["token_type"] == "bearer"
