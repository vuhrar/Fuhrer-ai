"""Unit tests for the ChatService."""
import os
from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

os.environ.setdefault("ENVIRONMENT", "testing")
os.environ.setdefault("SECRET_KEY", "test-secret-key-that-is-long-enough-for-testing-purposes-123456")

from kernel.exceptions import AuthorizationError, NotFoundError


def _make_conversation(user_id="user-1", messages=None):
    conv = MagicMock()
    conv.id = "conv-id-1"
    conv.title = "Test Chat"
    conv.model = "llama3"
    conv.user_id = user_id
    conv.messages = messages or []
    conv.created_at = datetime.now(UTC)
    conv.updated_at = datetime.now(UTC)
    return conv


def _make_message(role="assistant", content="Hello!"):
    msg = MagicMock()
    msg.id = "msg-id-1"
    msg.role = role
    msg.content = content
    msg.model = "llama3"
    msg.tokens_used = 42
    msg.created_at = datetime.now(UTC)
    return msg


class TestChatServiceUnit:
    @pytest.mark.asyncio
    async def test_create_conversation(self):
        from backend.services.chat.service import ChatService
        session = AsyncMock()
        mock_provider = AsyncMock()
        service = ChatService(session, provider=mock_provider)

        conv = _make_conversation()
        with patch.object(service._repo, "create", return_value=conv):
            result = await service.create_conversation("user-1", "My Chat")
            assert result["id"] == "conv-id-1"
            assert result["title"] == "Test Chat"

    @pytest.mark.asyncio
    async def test_list_conversations(self):
        from backend.services.chat.service import ChatService
        session = AsyncMock()
        service = ChatService(session)

        convs = [_make_conversation(), _make_conversation()]
        with patch.object(service._repo, "get_user_conversations", return_value=convs):
            result = await service.list_conversations("user-1")
            assert len(result) == 2

    @pytest.mark.asyncio
    async def test_get_conversation_success(self):
        from backend.services.chat.service import ChatService
        session = AsyncMock()
        service = ChatService(session)

        conv = _make_conversation(user_id="user-1")
        with patch.object(service._repo, "get_with_messages", return_value=conv):
            result = await service.get_conversation("conv-id-1", "user-1")
            assert result["id"] == "conv-id-1"

    @pytest.mark.asyncio
    async def test_get_conversation_not_found(self):
        from backend.services.chat.service import ChatService
        session = AsyncMock()
        service = ChatService(session)

        with patch.object(service._repo, "get_with_messages", return_value=None):
            with pytest.raises(NotFoundError):
                await service.get_conversation("nonexistent", "user-1")

    @pytest.mark.asyncio
    async def test_get_conversation_wrong_user(self):
        from backend.services.chat.service import ChatService
        session = AsyncMock()
        service = ChatService(session)

        conv = _make_conversation(user_id="other-user")
        with patch.object(service._repo, "get_with_messages", return_value=conv):
            with pytest.raises(AuthorizationError):
                await service.get_conversation("conv-id-1", "user-1")

    @pytest.mark.asyncio
    async def test_send_message_success(self):
        from backend.services.chat.service import ChatService
        session = AsyncMock()
        mock_provider = AsyncMock()
        mock_provider.chat.return_value = {
            "content": "AI response here",
            "model": "llama3",
            "tokens_used": 25,
        }
        service = ChatService(session, provider=mock_provider)

        conv = _make_conversation(user_id="user-1", messages=[])
        assistant_msg = _make_message(role="assistant", content="AI response here")

        with patch.object(service._repo, "get_with_messages", return_value=conv), \
             patch.object(service._repo, "add_message", return_value=assistant_msg), \
             patch.object(service._repo, "update", return_value=conv):
            result = await service.send_message("conv-id-1", "user-1", "Hello!")
            assert result["role"] == "assistant"
            assert result["content"] == "AI response here"

    @pytest.mark.asyncio
    async def test_send_message_wrong_user(self):
        from backend.services.chat.service import ChatService
        session = AsyncMock()
        service = ChatService(session)

        conv = _make_conversation(user_id="other-user")
        with patch.object(service._repo, "get_with_messages", return_value=conv):
            with pytest.raises(AuthorizationError):
                await service.send_message("conv-id-1", "user-1", "Hello!")

    @pytest.mark.asyncio
    async def test_delete_conversation(self):
        from backend.services.chat.service import ChatService
        session = AsyncMock()
        service = ChatService(session)

        conv = _make_conversation(user_id="user-1")
        with patch.object(service._repo, "get_by_id", return_value=conv), \
             patch.object(service._repo, "delete", return_value=None):
            await service.delete_conversation("conv-id-1", "user-1")
            service._repo.delete.assert_called_once()

    @pytest.mark.asyncio
    async def test_delete_conversation_wrong_user(self):
        from backend.services.chat.service import ChatService
        session = AsyncMock()
        service = ChatService(session)

        conv = _make_conversation(user_id="other-user")
        with patch.object(service._repo, "get_by_id", return_value=conv):
            with pytest.raises(AuthorizationError):
                await service.delete_conversation("conv-id-1", "user-1")
