"""Unit tests for the Plugin System."""
import pytest

from kernel.exceptions import ConflictError, PluginNotFoundError
from kernel.plugins import Plugin, PluginMetadata, PluginRegistry


class SamplePlugin(Plugin):
    def __init__(self, name: str = "sample-plugin"):
        self._name = name
        self.loaded = False
        self.unloaded = False

    @property
    def metadata(self) -> PluginMetadata:
        return PluginMetadata(
            name=self._name,
            version="1.0.0",
            description="A test plugin",
        )

    async def on_load(self) -> None:
        self.loaded = True

    async def on_unload(self) -> None:
        self.unloaded = True


@pytest.mark.asyncio
class TestPluginRegistry:
    async def test_register_plugin(self):
        registry = PluginRegistry()
        plugin = SamplePlugin()
        await registry.register(plugin)
        assert plugin.loaded

    async def test_list_plugins(self):
        registry = PluginRegistry()
        await registry.register(SamplePlugin("plugin-a"))
        await registry.register(SamplePlugin("plugin-b"))
        plugins = registry.list_plugins()
        names = [p.name for p in plugins]
        assert "plugin-a" in names
        assert "plugin-b" in names

    async def test_get_plugin(self):
        registry = PluginRegistry()
        plugin = SamplePlugin("my-plugin")
        await registry.register(plugin)
        retrieved = registry.get("my-plugin")
        assert retrieved is plugin

    async def test_get_nonexistent_raises(self):
        registry = PluginRegistry()
        with pytest.raises(PluginNotFoundError):
            registry.get("ghost")

    async def test_duplicate_registration_raises(self):
        registry = PluginRegistry()
        await registry.register(SamplePlugin("dup"))
        with pytest.raises(ConflictError):
            await registry.register(SamplePlugin("dup"))

    async def test_unregister_plugin(self):
        registry = PluginRegistry()
        plugin = SamplePlugin("to-remove")
        await registry.register(plugin)
        await registry.unregister("to-remove")
        assert plugin.unloaded
        with pytest.raises(PluginNotFoundError):
            registry.get("to-remove")

    async def test_unload_all(self):
        registry = PluginRegistry()
        p1 = SamplePlugin("p1")
        p2 = SamplePlugin("p2")
        await registry.register(p1)
        await registry.register(p2)
        await registry.unload_all()
        assert p1.unloaded
        assert p2.unloaded
        assert registry.list_plugins() == []

    async def test_health_check_default(self):
        plugin = SamplePlugin()
        result = await plugin.on_health_check()
        assert result["status"] == "ok"
