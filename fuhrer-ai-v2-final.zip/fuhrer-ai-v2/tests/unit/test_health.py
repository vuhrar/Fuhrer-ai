"""Unit tests for health monitoring."""
import pytest

from kernel.health import (
    ComponentHealth,
    HealthStatus,
    SystemHealth,
    check_cache,
    get_system_metrics,
)
from kernel.cache import InMemoryCache


class TestHealthStatus:
    def test_healthy_status(self):
        assert HealthStatus.HEALTHY == "healthy"

    def test_degraded_status(self):
        assert HealthStatus.DEGRADED == "degraded"

    def test_unhealthy_status(self):
        assert HealthStatus.UNHEALTHY == "unhealthy"


class TestComponentHealth:
    def test_healthy_component(self):
        comp = ComponentHealth(
            name="database",
            status=HealthStatus.HEALTHY,
            latency_ms=5.2,
        )
        assert comp.name == "database"
        assert comp.status == HealthStatus.HEALTHY
        assert comp.latency_ms == 5.2
        assert comp.error is None

    def test_unhealthy_component(self):
        comp = ComponentHealth(
            name="redis",
            status=HealthStatus.UNHEALTHY,
            error="Connection refused",
        )
        assert comp.error == "Connection refused"


class TestSystemHealth:
    def test_is_healthy_true(self):
        health = SystemHealth(
            status=HealthStatus.HEALTHY,
            version="2.0.0",
            uptime_seconds=100.0,
        )
        assert health.is_healthy

    def test_is_healthy_false(self):
        health = SystemHealth(
            status=HealthStatus.UNHEALTHY,
            version="2.0.0",
            uptime_seconds=100.0,
        )
        assert not health.is_healthy


@pytest.mark.asyncio
class TestHealthChecks:
    async def test_check_cache_healthy(self):
        cache = InMemoryCache()
        result = await check_cache(cache)
        assert result.name == "cache"
        assert result.status == HealthStatus.HEALTHY
        assert result.latency_ms is not None

    async def test_check_cache_unhealthy(self):
        from unittest.mock import AsyncMock
        broken_cache = AsyncMock()
        broken_cache.ping.side_effect = Exception("Redis down")
        result = await check_cache(broken_cache)
        assert result.status == HealthStatus.UNHEALTHY
        assert result.error is not None


class TestSystemMetrics:
    def test_get_system_metrics_returns_dict(self):
        metrics = get_system_metrics()
        assert isinstance(metrics, dict)
        assert "cpu_percent" in metrics
        assert "memory_percent" in metrics
