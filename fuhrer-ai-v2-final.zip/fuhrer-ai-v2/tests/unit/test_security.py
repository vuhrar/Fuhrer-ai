"""Unit tests for security primitives (JWT, passwords)."""
import os
import time

import pytest

os.environ.setdefault("ENVIRONMENT", "testing")
os.environ.setdefault("SECRET_KEY", "test-secret-key-that-is-long-enough-for-testing-purposes-123456")

from kernel.exceptions import TokenExpiredError, TokenInvalidError
from kernel.security import (
    create_access_token,
    create_refresh_token,
    decode_token,
    generate_secret,
    get_subject_from_token,
    hash_password,
    needs_rehash,
    sha256_hash,
    verify_password,
)
from kernel.security.tokens import TOKEN_TYPE_ACCESS, TOKEN_TYPE_REFRESH


class TestPasswordHashing:
    def test_hash_and_verify(self):
        password = "SecurePass123!"
        hashed = hash_password(password)
        assert hashed != password
        assert verify_password(password, hashed)

    def test_wrong_password_fails(self):
        hashed = hash_password("correct-password")
        assert not verify_password("wrong-password", hashed)

    def test_different_hashes_for_same_password(self):
        """Argon2id uses random salt — same password produces different hashes."""
        h1 = hash_password("password")
        h2 = hash_password("password")
        assert h1 != h2

    def test_needs_rehash_fresh_hash(self):
        hashed = hash_password("password")
        assert not needs_rehash(hashed)

    def test_generate_secret_length(self):
        secret = generate_secret(32)
        assert len(secret) > 0

    def test_sha256_hash(self):
        result = sha256_hash("hello")
        assert len(result) == 64
        assert result == sha256_hash("hello")  # deterministic

    def test_sha256_different_inputs(self):
        assert sha256_hash("hello") != sha256_hash("world")


class TestJWTTokens:
    def test_create_and_decode_access_token(self):
        token = create_access_token("user-123")
        payload = decode_token(token, expected_type=TOKEN_TYPE_ACCESS)
        assert payload["sub"] == "user-123"
        assert payload["type"] == TOKEN_TYPE_ACCESS

    def test_create_and_decode_refresh_token(self):
        token = create_refresh_token("user-456")
        payload = decode_token(token, expected_type=TOKEN_TYPE_REFRESH)
        assert payload["sub"] == "user-456"
        assert payload["type"] == TOKEN_TYPE_REFRESH

    def test_get_subject_from_token(self):
        token = create_access_token("user-789")
        subject = get_subject_from_token(token)
        assert subject == "user-789"

    def test_wrong_token_type_raises(self):
        access_token = create_access_token("user-1")
        with pytest.raises(TokenInvalidError):
            decode_token(access_token, expected_type=TOKEN_TYPE_REFRESH)

    def test_invalid_token_raises(self):
        with pytest.raises(TokenInvalidError):
            decode_token("not.a.valid.token")

    def test_tampered_token_raises(self):
        token = create_access_token("user-1")
        tampered = token[:-5] + "XXXXX"
        with pytest.raises(TokenInvalidError):
            decode_token(tampered)

    def test_extra_claims_in_token(self):
        token = create_access_token("user-1", extra_claims={"role": "admin"})
        payload = decode_token(token)
        assert payload["role"] == "admin"

    def test_integer_subject(self):
        token = create_access_token(42)
        subject = get_subject_from_token(token)
        assert subject == "42"
