"""Fuhrer Test Suite."""
