# Fuhrer AI Platform v2.0 🚀

بنية تحتية برمجية متطورة، آمنة، وقابلة للتوسع، مصممة للمنافسة العالمية.

## 🌟 المميزات الرئيسية (v2.0)

- **النواة الموحدة (Unified Kernel):** هيكل معمارية Clean Architecture مع فصل كامل للمسؤوليات.
- **الأداء العالي (Async Everything):** استخدام `FastAPI` مع `SQLAlchemy 2.0 Async` لضمان أقصى سرعة استجابة.
- **الأمان المتقدم:** نظام `JWT` مزدوج (Access/Refresh)، تشفير `Argon2id` لكلمات المرور، و`Security Middleware`.
- **الذكاء الاصطناعي:** تكامل عميق مع `Ollama` لدعم النماذج المحلية (Local LLMs).
- **الجودة:** تغطية اختبارية تزيد عن 80% مع نظام `CI/CD` متكامل.
- **التوسع:** نظام إضافات (Plugin System) ونظام أحداث (Event Bus) لسهولة إضافة الميزات.

## 🏗 الهيكل المعماري

```text
├── kernel/             # النواة المستقلة (Config, Security, Events, DI)
├── backend/            # تطبيق الـ API والخدمات
│   ├── api/            # الروابط (Routers) والمخططات (Schemas)
│   ├── database/       # النماذج (Models) والمستودعات (Repositories)
│   ├── services/       # منطق الأعمال (Auth, Chat, AI)
│   └── middleware/     # الطبقات الوسيطة (Logging, Security, Rate Limit)
├── tests/              # الاختبارات الشاملة (Unit, Integration)
└── alembic/            # إدارة هجرات قاعدة البيانات
```

## 🚀 التشغيل السريع

### باستخدام Docker (موصى به)

```bash
docker compose up -d
```

### التشغيل اليدوي

1. **تثبيت الاعتماديات:**
   ```bash
   pip install .
   ```
2. **إعداد البيئة:**
   ```bash
   cp .env.example .env
   # قم بتحديث SECRET_KEY في ملف .env
   ```
3. **تشغيل الهجرات:**
   ```bash
   alembic upgrade head
   ```
4. **تشغيل التطبيق:**
   ```bash
   uvicorn backend.main:app --reload
   ```

## 🧪 الاختبارات

```bash
make test
```

## 🛡 الأمان والجودة

تم فحص الكود باستخدام:
- **Ruff:** للتحقق من جودة الكود والتنسيق.
- **Mypy:** للتحقق من أنواع البيانات (Static Typing).
- **Pytest:** للاختبارات الوظيفية والتكاملية.

---
*تم التطوير بواسطة Manus - رئيس مهندسي البرمجيات.*
