from enum import StrEnum


class Environment(StrEnum):
    DEVELOPMENT = "development"
    TESTING = "testing"
    STAGING = "staging"
    PRODUCTION = "production"

    @property
    def is_debug(self) -> bool:
        return self in (Environment.DEVELOPMENT, Environment.TESTING)

    @property
    def is_production(self) -> bool:
        return self == Environment.PRODUCTION
