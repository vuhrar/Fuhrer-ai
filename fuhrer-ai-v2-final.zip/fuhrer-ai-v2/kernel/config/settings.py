from functools import lru_cache
from typing import Annotated

from pydantic import Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from .environment import Environment


class Settings(BaseSettings):
    """
    Central application settings loaded from environment variables.
    Single Source of Truth for the entire platform.
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    # ─── Application ─────────────────────────────────────────────────────────
    app_name: str = "Fuhrer"
    app_version: str = "2.0.0"
    environment: Environment = Environment.DEVELOPMENT
    debug: bool = False
    host: str = "0.0.0.0"
    port: int = Field(default=8000, ge=1, le=65535)

    # ─── Database ─────────────────────────────────────────────────────────────
    database_url: str = "sqlite+aiosqlite:///./fuhrer.db"
    database_pool_size: int = Field(default=10, ge=1, le=100)
    database_max_overflow: int = Field(default=20, ge=0, le=200)
    database_pool_timeout: int = Field(default=30, ge=5)
    database_pool_recycle: int = Field(default=1800, ge=60)

    # ─── Redis ────────────────────────────────────────────────────────────────
    redis_url: str = "redis://localhost:6379/0"
    redis_max_connections: int = Field(default=20, ge=1)
    cache_ttl_seconds: int = Field(default=300, ge=1)

    # ─── Security ─────────────────────────────────────────────────────────────
    secret_key: str = Field(default="")
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = Field(default=60, ge=1)
    refresh_token_expire_days: int = Field(default=30, ge=1)

    # ─── CORS ─────────────────────────────────────────────────────────────────
    cors_origins: list[str] = ["http://localhost:3000", "http://localhost:8080"]
    cors_allow_credentials: bool = True

    # ─── Rate Limiting ────────────────────────────────────────────────────────
    rate_limit_per_minute: int = Field(default=60, ge=1)
    rate_limit_per_hour: int = Field(default=1000, ge=1)

    # ─── AI Provider ─────────────────────────────────────────────────────────
    ollama_url: str = "http://localhost:11434"
    ollama_default_model: str = "llama3"
    ollama_timeout_seconds: int = Field(default=120, ge=10)
    ollama_max_retries: int = Field(default=3, ge=0)

    # ─── Vector DB ───────────────────────────────────────────────────────────
    vector_db: str = "chromadb"
    embedding_model: str = "bge-m3"
    chroma_host: str = "localhost"
    chroma_port: int = Field(default=8001, ge=1, le=65535)

    # ─── Logging ─────────────────────────────────────────────────────────────
    log_level: str = "INFO"
    log_file_rotation: str = "10 MB"
    log_file_retention: str = "30 days"

    @field_validator("cors_origins", mode="before")
    @classmethod
    def parse_cors_origins(cls, v: str | list[str]) -> list[str]:
        if isinstance(v, str):
            return [origin.strip() for origin in v.split(",") if origin.strip()]
        return v

    @model_validator(mode="after")
    def validate_secret_key(self) -> "Settings":
        if self.environment.is_production and not self.secret_key:
            raise ValueError(
                "SECRET_KEY must be set in production. "
                "Generate one with: python -c \"import secrets; print(secrets.token_urlsafe(64))\""
            )
        if not self.secret_key:
            import secrets
            object.__setattr__(self, "secret_key", secrets.token_urlsafe(64))
        return self

    @property
    def is_sqlite(self) -> bool:
        return "sqlite" in self.database_url

    @property
    def api_prefix(self) -> str:
        return "/api/v1"


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
