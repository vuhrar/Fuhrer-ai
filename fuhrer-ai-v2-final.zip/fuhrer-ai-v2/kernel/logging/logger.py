"""
Fuhrer Platform — Unified Structured Logging via Loguru.
"""
import sys
from pathlib import Path
from typing import Any

from loguru import logger

_configured = False
LOG_DIRECTORY = Path("logs")


def configure_logging(
    level: str = "INFO",
    rotation: str = "10 MB",
    retention: str = "30 days",
    diagnose: bool = False,
) -> None:
    """Configure the global Loguru logger. Idempotent — safe to call multiple times."""
    global _configured
    if _configured:
        return

    LOG_DIRECTORY.mkdir(exist_ok=True)
    logger.remove()

    # Console handler — structured, human-readable
    logger.add(
        sys.stdout,
        level=level,
        format=(
            "<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | "
            "<level>{level: <8}</level> | "
            "<cyan>{extra[module]}</cyan> | "
            "<level>{message}</level>"
        ),
        enqueue=True,
        backtrace=True,
        diagnose=diagnose,
        colorize=True,
    )

    # File handler — JSON-structured for log aggregation
    logger.add(
        LOG_DIRECTORY / "fuhrer.log",
        level=level,
        rotation=rotation,
        retention=retention,
        compression="zip",
        enqueue=True,
        backtrace=True,
        diagnose=diagnose,
        serialize=True,  # JSON format for log aggregators (ELK, Loki, etc.)
    )

    # Error-only file for quick triage
    logger.add(
        LOG_DIRECTORY / "fuhrer.errors.log",
        level="ERROR",
        rotation="5 MB",
        retention="90 days",
        compression="zip",
        enqueue=True,
        backtrace=True,
        diagnose=True,
        serialize=True,
    )

    _configured = True


def get_logger(module: str) -> Any:
    """Return a logger bound to the given module name."""
    return logger.bind(module=module)


def reset_logging() -> None:
    """Reset logging configuration (used in tests)."""
    global _configured
    _configured = False
