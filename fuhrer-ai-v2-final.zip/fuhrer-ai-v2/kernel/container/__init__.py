"""Fuhrer Platform — Dependency Injection Container."""

from .container import Container, container
from .lifetime import ServiceLifetime
from .provider import Provider
from .registry import ServiceRegistry
from .service import ServiceDescriptor

__all__ = [
    "Container",
    "container",
    "ServiceLifetime",
    "Provider",
    "ServiceRegistry",
    "ServiceDescriptor",
]
