from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from .lifetime import ServiceLifetime


@dataclass(slots=True)
class ServiceDescriptor:
    key: str
    implementation: Callable[..., Any]
    lifetime: ServiceLifetime
    instance: Any | None = field(default=None)
