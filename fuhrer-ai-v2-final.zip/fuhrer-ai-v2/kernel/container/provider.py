from abc import ABC, abstractmethod
from typing import Any


class Provider(ABC):
    """Abstract base for service providers (factories)."""

    @abstractmethod
    def build(self) -> Any:
        raise NotImplementedError
