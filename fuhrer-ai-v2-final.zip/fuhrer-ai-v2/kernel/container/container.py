"""
Fuhrer Platform — Dependency Injection Container.
Supports Singleton, Transient, and Scoped lifetimes.
"""
from collections.abc import Callable
from typing import Any, TypeVar

from .lifetime import ServiceLifetime
from .registry import ServiceRegistry

T = TypeVar("T")


class Container:
    """
    Application-level IoC container.

    Usage:
        container.singleton("db", lambda: Database())
        db = container.resolve("db")
    """

    def __init__(self) -> None:
        self._registry = ServiceRegistry()
        self._factories: dict[str, tuple[Callable[..., Any], ServiceLifetime]] = {}

    def singleton(self, key: str, service: Any) -> None:
        """Register a pre-built singleton instance."""
        self._registry.register(key, service)

    def register(
        self,
        key: str,
        factory: Callable[..., T],
        lifetime: ServiceLifetime = ServiceLifetime.SINGLETON,
    ) -> None:
        """Register a factory function with a given lifetime."""
        self._factories[key] = (factory, lifetime)

    def resolve(self, key: str) -> Any:
        """Resolve a registered service by key."""
        # Check pre-built singletons first
        if self._registry.contains(key):
            return self._registry.resolve(key)

        # Build from factory
        if key in self._factories:
            factory, lifetime = self._factories[key]
            instance = factory()
            if lifetime == ServiceLifetime.SINGLETON:
                self._registry.register(key, instance)
            return instance

        from kernel.exceptions import NotFoundError
        raise NotFoundError("Service", key)

    def override(self, key: str, service: Any) -> None:
        """Override a service (useful in tests)."""
        self._registry.override(key, service)

    def exists(self, key: str) -> bool:
        return self._registry.contains(key) or key in self._factories

    def clear(self) -> None:
        self._registry.clear()
        self._factories.clear()

    @property
    def registered_services(self) -> list[str]:
        return self._registry.registered_keys + list(self._factories.keys())


# Global application container
container = Container()
