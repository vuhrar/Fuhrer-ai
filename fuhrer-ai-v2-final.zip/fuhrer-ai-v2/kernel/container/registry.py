from typing import Any

from kernel.exceptions import ConflictError, NotFoundError


class ServiceRegistry:
    """Thread-safe in-memory service registry."""

    def __init__(self) -> None:
        self._services: dict[str, Any] = {}

    def register(self, key: str, service: Any) -> None:
        if key in self._services:
            raise ConflictError(f"Service '{key}' is already registered.")
        self._services[key] = service

    def override(self, key: str, service: Any) -> None:
        """Register or replace a service (used in tests)."""
        self._services[key] = service

    def resolve(self, key: str) -> Any:
        if key not in self._services:
            raise NotFoundError("Service", key)
        return self._services[key]

    def contains(self, key: str) -> bool:
        return key in self._services

    def clear(self) -> None:
        self._services.clear()

    @property
    def registered_keys(self) -> list[str]:
        return list(self._services.keys())
