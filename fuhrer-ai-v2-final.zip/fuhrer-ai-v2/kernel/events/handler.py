from abc import ABC, abstractmethod

from .event import Event


class EventHandler(ABC):
    """Abstract base for all event handlers."""

    @abstractmethod
    async def handle(self, event: Event) -> None:
        raise NotImplementedError
