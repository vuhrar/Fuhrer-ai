"""
Fuhrer Platform — Async Event Bus.
Supports multiple handlers per event with error isolation.
"""
from collections import defaultdict
from collections.abc import Callable, Coroutine
from typing import Any

from kernel.logging import get_logger

from .event import Event
from .handler import EventHandler

logger = get_logger(__name__)

AsyncHandlerFn = Callable[[Event], Coroutine[Any, Any, None]]


class EventBus:
    """
    In-process async event bus.

    Handlers are isolated: a failure in one handler does not affect others.
    """

    def __init__(self) -> None:
        self._handlers: dict[str, list[EventHandler]] = defaultdict(list)
        self._fn_handlers: dict[str, list[AsyncHandlerFn]] = defaultdict(list)

    def subscribe(self, event_name: str, handler: EventHandler) -> None:
        """Subscribe a handler object to an event."""
        self._handlers[event_name].append(handler)

    def on(self, event_name: str) -> Callable[[AsyncHandlerFn], AsyncHandlerFn]:
        """Decorator to subscribe an async function as an event handler."""
        def decorator(fn: AsyncHandlerFn) -> AsyncHandlerFn:
            self._fn_handlers[event_name].append(fn)
            return fn
        return decorator

    async def publish(self, event: Event) -> None:
        """Publish an event to all registered handlers."""
        logger.debug(f"Publishing event: {event!r}")

        # Class-based handlers
        for handler in self._handlers.get(event.name, []):
            try:
                await handler.handle(event)
            except Exception as exc:
                logger.error(
                    f"Handler {handler.__class__.__name__} failed for event "
                    f"'{event.name}': {exc}"
                )

        # Function-based handlers
        for fn in self._fn_handlers.get(event.name, []):
            try:
                await fn(event)
            except Exception as exc:
                logger.error(
                    f"Handler {fn.__name__} failed for event '{event.name}': {exc}"
                )

    def unsubscribe(self, event_name: str, handler: EventHandler) -> None:
        if event_name in self._handlers:
            self._handlers[event_name] = [
                h for h in self._handlers[event_name] if h is not handler
            ]

    def clear(self) -> None:
        self._handlers.clear()
        self._fn_handlers.clear()

    @property
    def subscribed_events(self) -> list[str]:
        return list(set(list(self._handlers.keys()) + list(self._fn_handlers.keys())))


# Global event bus
event_bus = EventBus()
