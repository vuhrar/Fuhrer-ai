from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any
from uuid import uuid4


@dataclass(slots=True)
class Event:
    """Immutable domain event."""

    id: str
    name: str
    payload: dict[str, Any]
    created_at: datetime
    source: str = "system"

    @classmethod
    def create(
        cls,
        name: str,
        payload: dict[str, Any] | None = None,
        source: str = "system",
    ) -> "Event":
        return cls(
            id=str(uuid4()),
            name=name,
            payload=payload or {},
            created_at=datetime.now(UTC),
            source=source,
        )

    def __repr__(self) -> str:
        return f"Event(name={self.name!r}, id={self.id!r}, source={self.source!r})"
