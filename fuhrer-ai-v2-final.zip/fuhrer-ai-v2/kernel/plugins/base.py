"""
Fuhrer Platform — Plugin System.
Micro-kernel architecture: all features are optional plugins.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

from kernel.logging import get_logger

logger = get_logger(__name__)


@dataclass
class PluginMetadata:
    name: str
    version: str
    description: str
    author: str = "Fuhrer Team"
    dependencies: list[str] = field(default_factory=list)


class Plugin(ABC):
    """Abstract base class for all Fuhrer plugins."""

    @property
    @abstractmethod
    def metadata(self) -> PluginMetadata:
        raise NotImplementedError

    @abstractmethod
    async def on_load(self) -> None:
        """Called when the plugin is loaded."""
        raise NotImplementedError

    @abstractmethod
    async def on_unload(self) -> None:
        """Called when the plugin is unloaded."""
        raise NotImplementedError

    async def on_health_check(self) -> dict[str, Any]:
        """Optional health check for this plugin."""
        return {"status": "ok"}


class PluginRegistry:
    """Registry for managing loaded plugins."""

    def __init__(self) -> None:
        self._plugins: dict[str, Plugin] = {}

    async def register(self, plugin: Plugin) -> None:
        name = plugin.metadata.name
        if name in self._plugins:
            from kernel.exceptions import ConflictError
            raise ConflictError(f"Plugin '{name}' is already registered.")
        logger.info(f"Loading plugin: {name} v{plugin.metadata.version}")
        await plugin.on_load()
        self._plugins[name] = plugin
        logger.info(f"Plugin '{name}' loaded successfully.")

    async def unregister(self, name: str) -> None:
        if name not in self._plugins:
            from kernel.exceptions import PluginNotFoundError
            raise PluginNotFoundError(name)
        plugin = self._plugins.pop(name)
        await plugin.on_unload()
        logger.info(f"Plugin '{name}' unloaded.")

    def get(self, name: str) -> Plugin:
        if name not in self._plugins:
            from kernel.exceptions import PluginNotFoundError
            raise PluginNotFoundError(name)
        return self._plugins[name]

    def list_plugins(self) -> list[PluginMetadata]:
        return [p.metadata for p in self._plugins.values()]

    async def unload_all(self) -> None:
        for name in list(self._plugins.keys()):
            await self.unregister(name)


# Global plugin registry
plugin_registry = PluginRegistry()
