"""Fuhrer Platform — Plugin System."""

from .base import Plugin, PluginMetadata, PluginRegistry, plugin_registry

__all__ = ["Plugin", "PluginMetadata", "PluginRegistry", "plugin_registry"]
