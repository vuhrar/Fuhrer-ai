"""
Fuhrer Platform — JWT Token Management.
Handles creation, validation, and revocation of access/refresh tokens.
"""
from datetime import UTC, datetime, timedelta
from typing import Any

import jwt
from jwt.exceptions import ExpiredSignatureError, InvalidTokenError

from kernel.config import settings
from kernel.exceptions import TokenExpiredError, TokenInvalidError
from kernel.logging import get_logger

logger = get_logger(__name__)

TOKEN_TYPE_ACCESS = "access"
TOKEN_TYPE_REFRESH = "refresh"


def create_access_token(
    subject: str | int,
    extra_claims: dict[str, Any] | None = None,
) -> str:
    """Create a signed JWT access token."""
    now = datetime.now(UTC)
    expire = now + timedelta(minutes=settings.access_token_expire_minutes)
    payload: dict[str, Any] = {
        "sub": str(subject),
        "iat": now,
        "exp": expire,
        "type": TOKEN_TYPE_ACCESS,
    }
    if extra_claims:
        payload.update(extra_claims)
    return jwt.encode(payload, settings.secret_key, algorithm=settings.jwt_algorithm)


def create_refresh_token(subject: str | int) -> str:
    """Create a signed JWT refresh token with longer expiry."""
    now = datetime.now(UTC)
    expire = now + timedelta(days=settings.refresh_token_expire_days)
    payload: dict[str, Any] = {
        "sub": str(subject),
        "iat": now,
        "exp": expire,
        "type": TOKEN_TYPE_REFRESH,
    }
    return jwt.encode(payload, settings.secret_key, algorithm=settings.jwt_algorithm)


def decode_token(token: str, expected_type: str = TOKEN_TYPE_ACCESS) -> dict[str, Any]:
    """
    Decode and validate a JWT token.

    Raises:
        TokenExpiredError: if the token has expired.
        TokenInvalidError: if the token is malformed or has wrong type.
    """
    try:
        payload: dict[str, Any] = jwt.decode(
            token,
            settings.secret_key,
            algorithms=[settings.jwt_algorithm],
        )
    except ExpiredSignatureError:
        raise TokenExpiredError()
    except InvalidTokenError as exc:
        raise TokenInvalidError(str(exc))

    token_type = payload.get("type")
    if token_type != expected_type:
        raise TokenInvalidError(
            f"Expected token type '{expected_type}', got '{token_type}'."
        )

    return payload


def get_subject_from_token(token: str) -> str:
    """Extract the subject (user ID) from a valid access token."""
    payload = decode_token(token, expected_type=TOKEN_TYPE_ACCESS)
    sub = payload.get("sub")
    if not sub:
        raise TokenInvalidError("Token is missing 'sub' claim.")
    return str(sub)
