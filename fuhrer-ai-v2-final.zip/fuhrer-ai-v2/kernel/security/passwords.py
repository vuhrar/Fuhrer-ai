"""
Fuhrer Platform — Password Hashing using Argon2id.
Argon2id is the recommended algorithm by OWASP for password hashing.
"""
from hashlib import sha256
from secrets import token_urlsafe

from argon2 import PasswordHasher
from argon2.exceptions import VerificationError, VerifyMismatchError

from kernel.exceptions import SecurityError

_hasher = PasswordHasher(
    time_cost=3,       # Number of iterations
    memory_cost=65536, # 64 MB memory usage
    parallelism=4,     # Parallel threads
    hash_len=32,
    salt_len=16,
)


def hash_password(password: str) -> str:
    """Hash a plaintext password using Argon2id."""
    return _hasher.hash(password)


def verify_password(plaintext: str, hashed: str) -> bool:
    """
    Verify a plaintext password against its Argon2id hash.
    Returns True if valid, False if mismatch.
    Raises SecurityError on unexpected verification failure.
    """
    try:
        return _hasher.verify(hashed, plaintext)
    except VerifyMismatchError:
        return False
    except VerificationError as exc:
        raise SecurityError(f"Password verification error: {exc}") from exc


def needs_rehash(hashed: str) -> bool:
    """Check if the hash needs to be upgraded (e.g., after parameter changes)."""
    return _hasher.check_needs_rehash(hashed)


def generate_secret(length: int = 64) -> str:
    """Generate a cryptographically secure random secret."""
    return token_urlsafe(length)


def sha256_hash(value: str) -> str:
    """Return the SHA-256 hex digest of a string."""
    return sha256(value.encode("utf-8")).hexdigest()
