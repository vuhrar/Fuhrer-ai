"""
Fuhrer Kernel — The Core Runtime of the Platform.

Provides:
    - Configuration (Single Source of Truth)
    - Structured Logging
    - Unified Exception Hierarchy
    - Dependency Injection Container
    - Async Event Bus
    - Security Primitives
    - Cache Abstraction
    - Health Monitoring
    - Plugin System

Everything in the backend depends on the Kernel.
"""

__version__ = "2.0.0"
