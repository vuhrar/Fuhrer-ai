"""
Fuhrer Platform — System Health Monitoring.
Provides structured health checks for all critical dependencies.
"""
import time
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

import psutil

from kernel.logging import get_logger

logger = get_logger(__name__)


class HealthStatus(StrEnum):
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"


@dataclass
class ComponentHealth:
    name: str
    status: HealthStatus
    latency_ms: float | None = None
    details: dict[str, Any] = field(default_factory=dict)
    error: str | None = None


@dataclass
class SystemHealth:
    status: HealthStatus
    version: str
    uptime_seconds: float
    components: list[ComponentHealth] = field(default_factory=list)
    system_metrics: dict[str, Any] = field(default_factory=dict)

    @property
    def is_healthy(self) -> bool:
        return self.status == HealthStatus.HEALTHY


_start_time = time.monotonic()


async def check_database(session_factory: Any) -> ComponentHealth:
    """Check database connectivity and response time."""
    start = time.monotonic()
    try:
        from sqlalchemy import text
        async with session_factory() as session:
            await session.execute(text("SELECT 1"))
        latency = (time.monotonic() - start) * 1000
        return ComponentHealth(
            name="database",
            status=HealthStatus.HEALTHY,
            latency_ms=round(latency, 2),
        )
    except Exception as exc:
        return ComponentHealth(
            name="database",
            status=HealthStatus.UNHEALTHY,
            error=str(exc),
        )


async def check_cache(cache: Any) -> ComponentHealth:
    """Check Redis/cache connectivity."""
    start = time.monotonic()
    try:
        is_alive = await cache.ping()
        latency = (time.monotonic() - start) * 1000
        return ComponentHealth(
            name="cache",
            status=HealthStatus.HEALTHY if is_alive else HealthStatus.UNHEALTHY,
            latency_ms=round(latency, 2),
        )
    except Exception as exc:
        return ComponentHealth(
            name="cache",
            status=HealthStatus.UNHEALTHY,
            error=str(exc),
        )


async def check_ollama(ollama_url: str) -> ComponentHealth:
    """Check Ollama AI provider availability."""
    start = time.monotonic()
    try:
        import httpx
        async with httpx.AsyncClient(timeout=5.0) as client:
            response = await client.get(f"{ollama_url}/api/tags")
        latency = (time.monotonic() - start) * 1000
        if response.status_code == 200:
            models = [m["name"] for m in response.json().get("models", [])]
            return ComponentHealth(
                name="ollama",
                status=HealthStatus.HEALTHY,
                latency_ms=round(latency, 2),
                details={"available_models": models},
            )
        return ComponentHealth(
            name="ollama",
            status=HealthStatus.DEGRADED,
            latency_ms=round(latency, 2),
            error=f"HTTP {response.status_code}",
        )
    except Exception as exc:
        return ComponentHealth(
            name="ollama",
            status=HealthStatus.UNHEALTHY,
            error=str(exc),
        )


def get_system_metrics() -> dict[str, Any]:
    """Collect system resource metrics."""
    try:
        cpu = psutil.cpu_percent(interval=0.1)
        mem = psutil.virtual_memory()
        disk = psutil.disk_usage("/")
        return {
            "cpu_percent": cpu,
            "memory_percent": mem.percent,
            "memory_available_mb": round(mem.available / 1024 / 1024, 1),
            "disk_percent": disk.percent,
            "disk_free_gb": round(disk.free / 1024 / 1024 / 1024, 2),
        }
    except Exception:
        return {}


async def get_full_health(
    version: str,
    session_factory: Any | None = None,
    cache: Any | None = None,
    ollama_url: str | None = None,
) -> SystemHealth:
    """Aggregate all component health checks into a single report."""
    components: list[ComponentHealth] = []

    if session_factory:
        components.append(await check_database(session_factory))
    if cache:
        components.append(await check_cache(cache))
    if ollama_url:
        components.append(await check_ollama(ollama_url))

    # Determine overall status
    statuses = {c.status for c in components}
    if HealthStatus.UNHEALTHY in statuses:
        overall = HealthStatus.UNHEALTHY
    elif HealthStatus.DEGRADED in statuses:
        overall = HealthStatus.DEGRADED
    else:
        overall = HealthStatus.HEALTHY

    return SystemHealth(
        status=overall,
        version=version,
        uptime_seconds=round(time.monotonic() - _start_time, 2),
        components=components,
        system_metrics=get_system_metrics(),
    )
