"""
Fuhrer Platform — Cache Abstraction Layer.
Supports Redis (production) with in-memory fallback (testing/development).
"""
import json
from abc import ABC, abstractmethod
from typing import Any

from kernel.logging import get_logger

logger = get_logger(__name__)


class CacheBackend(ABC):
    """Abstract cache backend interface."""

    @abstractmethod
    async def get(self, key: str) -> Any | None:
        raise NotImplementedError

    @abstractmethod
    async def set(self, key: str, value: Any, ttl: int | None = None) -> None:
        raise NotImplementedError

    @abstractmethod
    async def delete(self, key: str) -> None:
        raise NotImplementedError

    @abstractmethod
    async def exists(self, key: str) -> bool:
        raise NotImplementedError

    @abstractmethod
    async def clear_pattern(self, pattern: str) -> int:
        raise NotImplementedError

    @abstractmethod
    async def ping(self) -> bool:
        raise NotImplementedError


class RedisCache(CacheBackend):
    """Redis-backed cache implementation."""

    def __init__(self, redis_url: str, max_connections: int = 20, default_ttl: int = 300) -> None:
        self._url = redis_url
        self._max_connections = max_connections
        self._default_ttl = default_ttl
        self._client: Any = None

    async def _get_client(self) -> Any:
        if self._client is None:
            import redis.asyncio as aioredis
            self._client = aioredis.from_url(
                self._url,
                max_connections=self._max_connections,
                decode_responses=True,
            )
        return self._client

    async def get(self, key: str) -> Any | None:
        client = await self._get_client()
        try:
            raw = await client.get(key)
            if raw is None:
                return None
            return json.loads(raw)
        except Exception as exc:
            logger.warning(f"Cache GET failed for key '{key}': {exc}")
            return None

    async def set(self, key: str, value: Any, ttl: int | None = None) -> None:
        client = await self._get_client()
        try:
            serialized = json.dumps(value, default=str)
            await client.setex(key, ttl or self._default_ttl, serialized)
        except Exception as exc:
            logger.warning(f"Cache SET failed for key '{key}': {exc}")

    async def delete(self, key: str) -> None:
        client = await self._get_client()
        try:
            await client.delete(key)
        except Exception as exc:
            logger.warning(f"Cache DELETE failed for key '{key}': {exc}")

    async def exists(self, key: str) -> bool:
        client = await self._get_client()
        try:
            return bool(await client.exists(key))
        except Exception:
            return False

    async def clear_pattern(self, pattern: str) -> int:
        client = await self._get_client()
        try:
            keys = await client.keys(pattern)
            if keys:
                return await client.delete(*keys)
            return 0
        except Exception as exc:
            logger.warning(f"Cache CLEAR_PATTERN failed for '{pattern}': {exc}")
            return 0

    async def ping(self) -> bool:
        try:
            client = await self._get_client()
            return await client.ping()
        except Exception:
            return False

    async def close(self) -> None:
        if self._client:
            await self._client.aclose()
            self._client = None


class InMemoryCache(CacheBackend):
    """In-memory cache for testing and development (no Redis required)."""

    def __init__(self, default_ttl: int = 300) -> None:
        self._store: dict[str, Any] = {}
        self._default_ttl = default_ttl

    async def get(self, key: str) -> Any | None:
        return self._store.get(key)

    async def set(self, key: str, value: Any, ttl: int | None = None) -> None:
        self._store[key] = value

    async def delete(self, key: str) -> None:
        self._store.pop(key, None)

    async def exists(self, key: str) -> bool:
        return key in self._store

    async def clear_pattern(self, pattern: str) -> int:
        import fnmatch
        keys_to_delete = [k for k in self._store if fnmatch.fnmatch(k, pattern)]
        for k in keys_to_delete:
            del self._store[k]
        return len(keys_to_delete)

    async def ping(self) -> bool:
        return True

    def clear_all(self) -> None:
        self._store.clear()
