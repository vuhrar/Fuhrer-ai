"""
Fuhrer Platform — Unified Exception Hierarchy.
All application exceptions derive from FuhrerError.
"""
from http import HTTPStatus


class FuhrerError(Exception):
    """Base exception for the entire Fuhrer platform."""

    status_code: int = HTTPStatus.INTERNAL_SERVER_ERROR
    error_code: str = "INTERNAL_ERROR"

    def __init__(self, message: str = "An unexpected error occurred.") -> None:
        self.message = message
        super().__init__(message)

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(message={self.message!r})"


# ─── Infrastructure Errors ────────────────────────────────────────────────────

class ConfigurationError(FuhrerError):
    """Raised when the application is misconfigured."""
    status_code = HTTPStatus.INTERNAL_SERVER_ERROR
    error_code = "CONFIGURATION_ERROR"


class DatabaseError(FuhrerError):
    """Raised on database operation failures."""
    status_code = HTTPStatus.INTERNAL_SERVER_ERROR
    error_code = "DATABASE_ERROR"


class CacheError(FuhrerError):
    """Raised on cache operation failures."""
    status_code = HTTPStatus.INTERNAL_SERVER_ERROR
    error_code = "CACHE_ERROR"


class DependencyError(FuhrerError):
    """Raised when a required dependency is unavailable."""
    status_code = HTTPStatus.SERVICE_UNAVAILABLE
    error_code = "DEPENDENCY_ERROR"


# ─── Security Errors ─────────────────────────────────────────────────────────

class SecurityError(FuhrerError):
    """Base security exception."""
    status_code = HTTPStatus.UNAUTHORIZED
    error_code = "SECURITY_ERROR"


class AuthenticationError(SecurityError):
    """Raised when authentication fails."""
    status_code = HTTPStatus.UNAUTHORIZED
    error_code = "AUTHENTICATION_ERROR"

    def __init__(self, message: str = "Authentication failed.") -> None:
        super().__init__(message)


class AuthorizationError(SecurityError):
    """Raised when the user lacks required permissions."""
    status_code = HTTPStatus.FORBIDDEN
    error_code = "AUTHORIZATION_ERROR"

    def __init__(self, message: str = "Insufficient permissions.") -> None:
        super().__init__(message)


class TokenExpiredError(AuthenticationError):
    """Raised when a JWT token has expired."""
    error_code = "TOKEN_EXPIRED"

    def __init__(self, message: str = "Token has expired.") -> None:
        super().__init__(message)


class TokenInvalidError(AuthenticationError):
    """Raised when a JWT token is invalid or malformed."""
    error_code = "TOKEN_INVALID"

    def __init__(self, message: str = "Token is invalid.") -> None:
        super().__init__(message)


# ─── Domain Errors ────────────────────────────────────────────────────────────

class NotFoundError(FuhrerError):
    """Raised when a requested resource is not found."""
    status_code = HTTPStatus.NOT_FOUND
    error_code = "NOT_FOUND"

    def __init__(self, resource: str = "Resource", identifier: str | int | None = None) -> None:
        msg = f"{resource} not found."
        if identifier is not None:
            msg = f"{resource} with id '{identifier}' not found."
        super().__init__(msg)


class ConflictError(FuhrerError):
    """Raised when a resource already exists."""
    status_code = HTTPStatus.CONFLICT
    error_code = "CONFLICT"


class ValidationError(FuhrerError):
    """Raised when input validation fails."""
    status_code = HTTPStatus.UNPROCESSABLE_ENTITY
    error_code = "VALIDATION_ERROR"


class RateLimitError(FuhrerError):
    """Raised when rate limit is exceeded."""
    status_code = HTTPStatus.TOO_MANY_REQUESTS
    error_code = "RATE_LIMIT_EXCEEDED"

    def __init__(self, message: str = "Rate limit exceeded. Please try again later.") -> None:
        super().__init__(message)


# ─── AI Errors ────────────────────────────────────────────────────────────────

class AIProviderError(FuhrerError):
    """Raised when the AI provider (Ollama) is unavailable or returns an error."""
    status_code = HTTPStatus.BAD_GATEWAY
    error_code = "AI_PROVIDER_ERROR"


class ModelNotFoundError(AIProviderError):
    """Raised when the requested AI model is not available."""
    error_code = "MODEL_NOT_FOUND"

    def __init__(self, model: str) -> None:
        super().__init__(f"AI model '{model}' is not available.")


# ─── Plugin Errors ────────────────────────────────────────────────────────────

class PluginError(FuhrerError):
    """Base plugin exception."""
    error_code = "PLUGIN_ERROR"


class PluginNotFoundError(PluginError):
    """Raised when a plugin is not registered."""
    status_code = HTTPStatus.NOT_FOUND
    error_code = "PLUGIN_NOT_FOUND"

    def __init__(self, plugin_name: str) -> None:
        super().__init__(f"Plugin '{plugin_name}' is not registered.")


class PluginLoadError(PluginError):
    """Raised when a plugin fails to load."""
    error_code = "PLUGIN_LOAD_ERROR"
